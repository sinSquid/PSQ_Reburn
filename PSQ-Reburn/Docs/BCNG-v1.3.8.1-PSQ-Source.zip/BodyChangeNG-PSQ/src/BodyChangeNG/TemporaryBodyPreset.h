#pragma once

#include "BodyChangeNG/SliderName.h"
#include <cmath>
#include <cstdint>
#include <limits>
#include <string_view>

// Optional PSQ adapter. These policies have no engine dependency and are
// exercised directly by the standalone adapter checks.
namespace bcn::temporary_body
{
    inline constexpr auto key = "BodyChangeNGTemporary:PSQ Reburn";
    inline constexpr auto marker = "BCNGTemporaryPreset:PSQ";
    enum Status : std::int32_t {
        pending = 0, applied = 1, cleared = 2,
        invalidActor = -1, unavailable = -2, invalidPreset = -3,
        editing = -4, superseded = -5, applicationFailed = -6,
        nonAdditive = -7
    };
    using Values = slider_name::Map<float>;

    [[nodiscard]] constexpr bool NormalBaseKey(const std::string_view source) noexcept
    {
        return source == "BodyChangeNG" || source == "BodyChangerNG" ||
            source == "BodyChangeNGEditorBaseline" || source == "BodyChangeNGEditorOffset" ||
            source == "OBody" || source == "OClothe" ||
            source == "RaceMenuMorphsCBBE.esp" || source == "RaceMenuMorphsHIMBO.esp" ||
            source == "UBE_RaceMenuMorphs.esp";
    }

    [[nodiscard]] inline bool Finite(const Values& values)
    {
        for (const auto& [name, value] : values)
            if (name.empty() || !std::isfinite(value)) return false;
        return true;
    }

    // Preserve all source layers verbatim. One owned additive correction
    // replaces only recognized normal-body contributions, never FHU/SLIF or
    // arbitrary foreign keys. Missing preset sliders target the build default.
    [[nodiscard]] inline Values Deltas(const Values& desired, const Values& normal)
    {
        auto values = desired;
        for (const auto& [name, value] : normal) values[name] -= value;
        return values;
    }

    [[nodiscard]] constexpr bool Current(const std::int32_t request,
        const std::int32_t latest, const std::uint64_t acceptedEpoch,
        const std::uint64_t currentEpoch) noexcept
    {
        return request > 0 && request == latest && acceptedEpoch == currentEpoch;
    }

    template <class API, class Actor>
    [[nodiscard]] bool UsesAdditive(API& api, Actor* actor)
    {
        constexpr auto probe = "BodyChangeNG:PSQModeProbe";
        api.SetMorph(actor, probe, key, .25F);
        api.SetMorph(actor, probe, probe, .75F);
        const auto combined = api.GetBodyMorphs(actor, probe);
        api.ClearBodyMorphNames(actor, probe);
        return std::isfinite(combined) && std::abs(combined - 1.F) < .00001F;
    }

    // These are the actual production-owned write/clear operations. Their
    // injectable refresh/current gates allow fake-backend regression tests
    // without reproducing a second implementation of the adapter algorithm.
    template <class API, class Actor, class CurrentGate, class Refresh>
    [[nodiscard]] Status Apply(API& api, Actor* actor, const Values& deltas,
        CurrentGate&& current, Refresh&& refresh)
    {
        if (!Finite(deltas)) return applicationFailed;
        if (!current()) return superseded;
        api.ClearBodyMorphKeys(actor, key);
        for (const auto& [name, value] : deltas) {
            if (!current()) return superseded;
            api.SetMorph(actor, name.c_str(), key, value);
        }
        if (!current()) return superseded;
        // Reserved name has no TRI. A nonzero sentinel remains owned even if
        // the provider elides zero-valued morph entries for a Zeroed preset.
        api.SetMorph(actor, marker, key, 1.F);
        if (!current()) return superseded;
        refresh();
        if (!current()) return superseded;
        bool matches = api.HasBodyMorphKey(actor, key);
        for (const auto& [name, value] : deltas)
            matches &= std::abs(api.GetMorph(actor, name.c_str(), key) - value) < .00001F;
        return matches ? applied : applicationFailed;
    }

    template <class API, class Actor, class CurrentGate, class Refresh>
    [[nodiscard]] Status Clear(API& api, Actor* actor, CurrentGate&& current, Refresh&& refresh)
    {
        if (!current()) return superseded;
        const auto changed = api.HasBodyMorphKey(actor, key);
        api.ClearBodyMorphKeys(actor, key);
        if (!current()) return superseded;
        if (changed) refresh();
        if (!current()) return superseded;
        return api.HasBodyMorphKey(actor, key) ? applicationFailed : cleared;
    }
}
