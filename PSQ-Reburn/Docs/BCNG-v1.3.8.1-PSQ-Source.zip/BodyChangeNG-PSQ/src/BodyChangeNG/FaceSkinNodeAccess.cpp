#include "BodyChangeNG/FaceSkinNodeAccess.h"
#include "BodyChangeNG/FaceSkinPolicy.h"
#include "BodyChangeNG/FaceNodeSelection.h"
#include "BodyChangeNG/RaceMenuOverrideABI.h"
#include "BodyChangeNG/RaceMenuBodyMorph.h"
#include <RE/B/BSVisit.h>
#include <RE/B/BSFaceGenNiNode.h>
#include <RE/B/BSLightingShaderMaterialBase.h>
#include <algorithm>

namespace
{
    using namespace bcn::racemenu_abi;
    using bcn::racemenu_compat::NodeOverrideAbi;
    constexpr std::uint16_t textureKey = 9;
    bool Valid(RE::Actor* actor, const std::string& node, unsigned channel)
    {
        return !node.empty() && bcn::face_skin::ResolveNodeName(actor) == node &&
            std::ranges::find(bcn::face_skin::kChannels, channel) != bcn::face_skin::kChannels.end();
    }
    class StringValue final : public IOverrideInterfaceV2::SetVariant
    {
    public:
        explicit StringValue(const std::string& value) : value_(value) {}
        Type GetType() override { return Type::String; }
        const char* String() override { return value_.c_str(); }
    private:
        const std::string& value_;
    };
    class StringResult final : public IOverrideInterfaceV2::GetVariant
    {
    public:
        void Int(std::int32_t) override {}
        void Float(float) override {}
        void String(const char* value) override { text = value ? value : ""; stringReceived = true; }
        void Bool(bool) override {}
        void TextureSet(const RE::BGSTextureSet*) override {}
        std::string text;
        bool stringReceived{};
    };
}

namespace bcn::face_skin
{
    std::string ResolveNodeName(RE::Actor* actor)
    {
        if (!actor || !actor->Is3DLoaded() ||
            runtime::ResolveGameBranch(REL::Module::get().version()) == runtime::GameBranch::unsupported) return {};
        auto* face = actor->GetFaceNodeSkinned();
        auto* root = actor->Get3D(false);
        auto* base = actor->GetActorBase();
        if (!face || !root || !base) return {};
        const auto* head = base->GetCurrentHeadPartByType(RE::BGSHeadPart::HeadPartType::kFace);
        const std::string_view preferred = head && !head->formEditorID.empty() ?
            std::string_view{ head->formEditorID.c_str() } : std::string_view{};
        NodeSelection selected;
        RE::BSGeometry* selectedGeometry{};
        RE::BSVisit::TraverseScenegraphGeometries(face, [&](RE::BSGeometry* geometry) {
            if (!geometry || geometry->name.empty()) return RE::BSVisit::BSVisitControl::kContinue;
            auto* shader = geometry->lightingShaderProp_cast();
            auto* material = shader ? shader->material : nullptr;
            if (!material || material->GetType() != RE::BSShaderMaterial::Type::kLighting)
                return RE::BSVisit::BSVisitControl::kContinue;
            const auto feature = material->GetFeature();
            const auto previousRank = selected.rank;
            selected.Consider(geometry->name.c_str(), feature == RE::BSShaderMaterial::Feature::kFaceGen,
                feature == RE::BSShaderMaterial::Feature::kFaceGenRGBTint, preferred);
            if (selected.rank > previousRank) selectedGeometry = geometry;
            return RE::BSVisit::BSVisitControl::kContinue;
        });
        // One root lookup after the small face-subtree scan, not one lookup
        // per head/hair shape. NiOverride must resolve the SAME geometry.
        if (selected.Result().empty() || !selectedGeometry ||
            root->GetObjectByName(selectedGeometry->name) != selectedGeometry) return {};
        return std::string{ selected.Result() };
    }

    NodeAccess NodeAccess::Connect()
    {
        NodeAccess result;
        const auto branch = runtime::ResolveGameBranch(REL::Module::get().version());
        if (branch == runtime::GameBranch::unsupported) return result;
        auto* provider = static_cast<IPluginInterface*>(racemenu::QueryInterface("Override"));
        if (!provider) return result;
        result.abi_ = racemenu_compat::ResolveNodeOverrideAbi(provider->GetVersion(), branch);
        if (result.abi_ != NodeOverrideAbi::papyrus) result.interface_ = provider;
        return result;
    }
    const char* NodeAccess::Label() const noexcept
    {
        switch (abi_) {
        case NodeOverrideAbi::legacyV1: return "Override-v1 immediate";
        case NodeOverrideAbi::publicV2: return "Override-v2 prefix immediate";
        default: return "Papyrus fallback";
        }
    }
    bool NodeAccess::Read(RE::Actor* actor, bool female, const std::string& node,
        unsigned channel, bool saved, std::string& value) const
    {
        value.clear();
        // Saved keys on a previous head must remain readable for cleanup.
        if (!interface_ || !actor || node.empty() ||
            std::ranges::find(kChannels, channel) == kChannels.end() || (!saved && !Valid(actor, node, channel))) return false;
        if (abi_ == NodeOverrideAbi::legacyV1) {
            auto* api = static_cast<IOverrideInterfaceV1*>(interface_);
            const RE::BSFixedString name(node);
            LegacyOverrideVariant property;
            property.key = textureKey;
            property.index = static_cast<std::int8_t>(channel);
            const auto* found = saved ? api->GetNodeOverride(actor, female, name, textureKey,
                static_cast<std::uint8_t>(channel)) : &property;
            if (!saved) api->GetNodeProperty(actor, false, name, &property);
            if (found && found->type == LegacyOverrideVariant::kTypeString && found->string)
                value = found->string->c_str(); // copy before any registry mutation
            return true;
        }
        auto* api = static_cast<IOverrideInterfaceV2*>(interface_);
        StringResult result;
        if (saved) {
            api->GetNodeOverride(actor, female, node.c_str(), textureKey, static_cast<std::uint8_t>(channel), result);
        } else if (!api->GetNodeProperty(actor, false, node.c_str(), textureKey, static_cast<std::uint8_t>(channel), result)) return false;
        value = std::move(result.text);
        return true;
    }
    bool NodeAccess::Write(RE::Actor* actor, bool female, const std::string& node,
        unsigned channel, const std::string& value, bool persist) const
    {
        if (!interface_ || value.empty() || !Valid(actor, node, channel)) return false;
        const auto index = static_cast<std::uint8_t>(channel);
        if (abi_ == NodeOverrideAbi::legacyV1) {
            auto* api = static_cast<IOverrideInterfaceV1*>(interface_);
            const RE::BSFixedString name(node); // owns trivial borrowed LegacyNodeName
            auto write = LegacyOverrideVariant::String(textureKey, index, value);
            // v1 AddNodeOverride copies its argument without interning it.
            // GetNodeProperty supplies RaceMenu's own serializable string.
            LegacyOverrideVariant interned;
            interned.key = textureKey;
            interned.index = static_cast<std::int8_t>(index);
            return WriteLegacyString(value, persist,
                [&] { api->SetNodeProperty(actor, name, &write, true); },
                [&]() -> std::string {
                    api->GetNodeProperty(actor, false, name, &interned);
                    return interned.type == LegacyOverrideVariant::kTypeString && interned.string ?
                        std::string(interned.string->c_str()) : std::string{};
                },
                [&] { api->AddNodeOverride(actor, female, name, interned); });
        }
        auto* api = static_cast<IOverrideInterfaceV2*>(interface_);
        StringValue write(value);
        if (persist) api->AddNodeOverride(actor, female, node.c_str(), textureKey, index, write);
        // v1 handles both views internally; public v2 takes an explicit view.
        // Match the existing Papyrus behavior without applying twice to an
        // object shared by first and third person.
        RE::NiAVObject* last{};
        bool applied{};
        for (const bool firstPerson : { false, true }) {
            auto* root = actor->Get3D(firstPerson);
            auto* object = root ? root->GetObjectByName(RE::BSFixedString(node)) : nullptr;
            if (!object || object == last) continue;
            api->SetNodeProperty(actor, firstPerson, node.c_str(), textureKey, index, write, true);
            last = object;
            applied = true;
        }
        return applied;
    }
    bool NodeAccess::Remove(RE::Actor* actor, bool female, const std::string& node, unsigned channel) const
    {
        if (!interface_ || !actor || node.empty() || std::ranges::find(kChannels, channel) == kChannels.end()) return false;
        if (abi_ == NodeOverrideAbi::legacyV1) {
            const RE::BSFixedString name(node);
            static_cast<IOverrideInterfaceV1*>(interface_)->RemoveNodeOverride(actor, female, name, textureKey, static_cast<std::uint8_t>(channel));
        } else {
            static_cast<IOverrideInterfaceV2*>(interface_)->RemoveNodeOverride(actor, female, node.c_str(), textureKey, static_cast<std::uint8_t>(channel));
        }
        return true;
    }

    bool NodeAccess::ReadSaved(RE::Actor* actor, bool female, const std::string& node,
        unsigned channel, SavedKey& value) const
    {
        value = {};
        if (!interface_ || !actor || node.empty() || std::ranges::find(kChannels, channel) == kChannels.end()) return false;
        const auto index = static_cast<std::uint8_t>(channel);
        if (abi_ == NodeOverrideAbi::legacyV1) {
            const RE::BSFixedString name(node);
            const auto* found = static_cast<IOverrideInterfaceV1*>(interface_)->GetNodeOverride(actor, female, name, textureKey, index);
            if (!found || found->type == LegacyOverrideVariant::kTypeNone) return true;
            if (found->type != LegacyOverrideVariant::kTypeString || !found->string) return false;
            value.legacy = *found;
            value.path = value.legacy.string->c_str();
        } else {
            auto* api = static_cast<IOverrideInterfaceV2*>(interface_);
            if (!api->HasNodeOverride(actor, female, node.c_str(), textureKey, index)) return true;
            StringResult result;
            if (!api->GetNodeOverride(actor, female, node.c_str(), textureKey, index, result) || !result.stringReceived) return false;
            value.path = std::move(result.text);
        }
        value.present = true;
        return true;
    }

    bool NodeAccess::RestoreSaved(RE::Actor* actor, bool female, const std::string& node,
        unsigned channel, const SavedKey& value) const
    {
        if (!interface_ || !actor || node.empty() || std::ranges::find(kChannels, channel) == kChannels.end()) return false;
        if (!value.present) return Remove(actor, female, node, channel);
        if (abi_ == NodeOverrideAbi::legacyV1) {
            if (value.legacy.type != LegacyOverrideVariant::kTypeString || !value.legacy.string) return false;
            const RE::BSFixedString name(node);
            auto original = value.legacy;
            static_cast<IOverrideInterfaceV1*>(interface_)->AddNodeOverride(actor, female, name, original);
        } else {
            StringValue original(value.path);
            static_cast<IOverrideInterfaceV2*>(interface_)->AddNodeOverride(actor, female, node.c_str(),
                textureKey, static_cast<std::uint8_t>(channel), original);
        }
        return true;
    }

    bool NodeAccess::SaveCurrent(RE::Actor* actor, bool female, const std::string& node,
        unsigned channel, const std::string& path) const
    {
        if (!interface_ || path.empty() || !Valid(actor, node, channel)) return false;
        SavedKey current;
        current.present = true;
        current.path = path;
        if (abi_ == NodeOverrideAbi::legacyV1) {
            const RE::BSFixedString name(node);
            current.legacy.key = textureKey;
            current.legacy.index = static_cast<std::int8_t>(channel);
            static_cast<IOverrideInterfaceV1*>(interface_)->GetNodeProperty(actor, false, name, &current.legacy);
            if (current.legacy.type != LegacyOverrideVariant::kTypeString || !current.legacy.string ||
                !Owns(current.legacy.string->c_str(), path)) return false;
        } else {
            std::string live;
            if (!Read(actor, female, node, channel, false, live) || !Owns(live, path)) return false;
        }
        return RestoreSaved(actor, female, node, channel, current);
    }
}
