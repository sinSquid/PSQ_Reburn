#pragma once

#include <RE/B/BSTEvent.h>
#include <RE/I/InputEvent.h>

#include <atomic>
#include <cstddef>
#include <mutex>
#include <unordered_set>
#include <utility>
#include <vector>

namespace bcn
{
    class InputSink final : public RE::BSTEventSink<RE::InputEvent*>
    {
    public:
        static InputSink& Get();

        void Register();
        void BeginHotkeyCapture();
        void CancelHotkeyCapture();
        void ResetTransientState();
        [[nodiscard]] bool IsCapturingHotkey() const noexcept;
        // Called before gameplay filtering: captured presses stay private,
        // but their releases must still retire this sink's held-key state.
        void ProcessHotkeyCaptureButton(const RE::ButtonEvent& a_event);
        // Observe console-owned edges without invoking capture or shortcuts.
        void ObserveKeyboardButton(const RE::ButtonEvent& a_event);
        void QueueHotkeyCaptureRelease(std::uint32_t a_scanCode, std::size_t a_precedingButtons);
        void FinishHotkeyCaptureReleases();

        RE::BSEventNotifyControl ProcessEvent(RE::InputEvent* const* a_events,
            RE::BSTEventSource<RE::InputEvent*>*) override;

    private:
        void ProcessKeyboardButton(const RE::ButtonEvent& a_event);
        void RetireHotkeyCaptureReleases(std::size_t a_precedingButtons);
        void RequestToggle(std::string_view a_source);
        void StartFocusedWindowHotkeyFallback();
        [[nodiscard]] bool CtrlDown() const noexcept;
        [[nodiscard]] bool ShiftDown() const noexcept;
        [[nodiscard]] bool AltDown() const noexcept;

        mutable std::mutex lock_;
        std::unordered_set<std::uint32_t> heldKeys_;
        // Values only, scoped to the current filtered dispatcher call.
        std::vector<std::pair<std::size_t, std::uint32_t>> captureReleases_;
        std::atomic_bool registered_{ false };
        std::atomic_bool capture_{ false };
        std::atomic_bool focusedWindowFallbackStarted_{ false };
        std::atomic<std::int64_t> lastToggleMilliseconds_{ 0 };
    };
}
