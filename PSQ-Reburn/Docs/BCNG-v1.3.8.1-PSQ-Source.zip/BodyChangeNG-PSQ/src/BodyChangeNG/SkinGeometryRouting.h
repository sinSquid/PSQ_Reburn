#pragma once

#include <cstddef>
#include <cstdint>
#include <string_view>

namespace bcn::skin_geometry
{
    enum class BodySelection
    {
        all,
        regular,
        cbbeGenitalAnal,
        unpGenitalAnal,
        maleGenitals
    };

    enum class LimbSelection
    {
        hands,
        feet
    };

    // UBE normally exposes its naked body on slot 53, but some valid UBE
    // skin-armour/equipment states expose the live body geometry through the
    // ordinary slot 32 instead. Only fall back when the UBE-specific target is
    // genuinely absent; an apply failure on an existing target must not spill
    // the profile onto a second body object.
    [[nodiscard]] constexpr bool NeedsStandardBodyFallback(
        const bool usesUbeBodySlot, const std::size_t usableUbeTargets) noexcept
    {
        return usesUbeBodySlot && usableUbeTargets == 0U;
    }

    [[nodiscard]] constexpr char LowerAscii(const char value) noexcept
    {
        return value >= 'A' && value <= 'Z' ? static_cast<char>(value + ('a' - 'A')) : value;
    }

    [[nodiscard]] constexpr bool EqualsIgnoreAsciiCase(
        const std::string_view left, const std::string_view right) noexcept
    {
        if (left.size() != right.size()) return false;
        for (std::size_t index = 0; index < left.size(); ++index) {
            if (LowerAscii(left[index]) != LowerAscii(right[index])) return false;
        }
        return true;
    }

    [[nodiscard]] constexpr bool ContainsIgnoreAsciiCase(
        const std::string_view value, const std::string_view token) noexcept
    {
        if (token.empty()) return true;
        if (token.size() > value.size()) return false;
        for (std::size_t start{}; start + token.size() <= value.size(); ++start) {
            bool match{ true };
            for (std::size_t index{}; index < token.size(); ++index) {
                if (LowerAscii(value[start + index]) != LowerAscii(token[index])) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    }

    [[nodiscard]] constexpr bool MatchesLimb(
        const LimbSelection selection, const std::string_view nodeName,
        const std::string_view texturePath = {}) noexcept
    {
        if (selection == LimbSelection::hands) {
            return ContainsIgnoreAsciiCase(nodeName, "hand") ||
                ContainsIgnoreAsciiCase(texturePath, "hands");
        }
        return ContainsIgnoreAsciiCase(nodeName, "feet") ||
            ContainsIgnoreAsciiCase(nodeName, "foot") ||
            ContainsIgnoreAsciiCase(texturePath, "feet");
    }

    // Shared-atlas limbs cannot always be identified by their texture path:
    // UBE uses !UBE\Body for both hands and feet, while CBBE/BHUNP feet use
    // the body atlas. Worn outfit NIFs still expose embedded skin as a
    // dedicated Hands/Feet geometry beside glove/boot geometries. Keep this
    // deliberately exact: a generic body or outfit node must never be routed
    // into a hand or foot override.
    [[nodiscard]] constexpr bool MatchesExplicitLimbNode(
        const LimbSelection selection, const std::string_view nodeName) noexcept
    {
        if (selection == LimbSelection::hands) {
            return EqualsIgnoreAsciiCase(nodeName, "hand") ||
                EqualsIgnoreAsciiCase(nodeName, "hands") ||
                EqualsIgnoreAsciiCase(nodeName, "femalehands");
        }
        return EqualsIgnoreAsciiCase(nodeName, "foot") ||
            EqualsIgnoreAsciiCase(nodeName, "feet") ||
            EqualsIgnoreAsciiCase(nodeName, "femalefeet");
    }

    [[nodiscard]] constexpr bool MatchesExplicitRequestedLimbNode(
        const std::uint32_t requestedSlotMask, const std::uint32_t handsSlotMask,
        const std::uint32_t feetSlotMask, const std::string_view nodeName) noexcept
    {
        if (requestedSlotMask == handsSlotMask) {
            return MatchesExplicitLimbNode(LimbSelection::hands, nodeName);
        }
        if (requestedSlotMask == feetSlotMask) {
            return MatchesExplicitLimbNode(LimbSelection::feet, nodeName);
        }
        return false;
    }

    // Hidden-equipment and multi-slot NIFs can anchor an exposed hand or foot
    // geometry under a biped entry other than slot 33/37. Cross-slot discovery
    // is safe only with exact limb evidence on a verified skin material. This
    // keeps fabric, glove, boot, body and genital materials out of limb
    // skin targets even when an outfit author reused a limb-like name.
    [[nodiscard]] constexpr bool IsSafeCrossSlotLimbCandidate(
        const std::uint32_t requestedSlotMask, const std::uint32_t handsSlotMask,
        const std::uint32_t feetSlotMask, const std::string_view nodeName,
        const std::string_view texturePath, const bool skinGeometry) noexcept
    {
        if (!skinGeometry) return false;
        if (requestedSlotMask == handsSlotMask) {
            return MatchesLimb(LimbSelection::hands, nodeName, texturePath);
        }
        if (requestedSlotMask == feetSlotMask) {
            return MatchesLimb(LimbSelection::feet, nodeName, texturePath);
        }
        return false;
    }

    [[nodiscard]] constexpr bool IsHandsOrFeetSlotPart(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        return MatchesLimb(LimbSelection::hands, nodeName, texturePath) ||
            MatchesLimb(LimbSelection::feet, nodeName, texturePath);
    }

    [[nodiscard]] constexpr bool MatchesRequestedPart(
        const std::uint32_t requestedSlotMask, const std::uint32_t bodySlotMask,
        const std::uint32_t handsSlotMask, const std::uint32_t feetSlotMask,
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        if (requestedSlotMask == handsSlotMask) {
            return MatchesLimb(LimbSelection::hands, nodeName, texturePath);
        }
        if (requestedSlotMask == feetSlotMask) {
            return MatchesLimb(LimbSelection::feet, nodeName, texturePath);
        }
        // A naked Skin Armor may expose one multi-slot clone from each biped
        // entry. Keep its hand/foot geometries out of a slot-32 body request.
        if (requestedSlotMask == bodySlotMask) {
            return !IsHandsOrFeetSlotPart(nodeName, texturePath);
        }
        return true;
    }

    [[nodiscard]] constexpr bool IsCBBEGenitalAnalTexture(
        const std::string_view texturePath) noexcept
    {
        return ContainsIgnoreAsciiCase(texturePath, "femalebody_etc_v2_1");
    }

    [[nodiscard]] constexpr bool IsUNPGenitalAnalTexture(
        const std::string_view texturePath) noexcept
    {
        return ContainsIgnoreAsciiCase(texturePath, "bakaunp\\vaginalanalcanal2") ||
            ContainsIgnoreAsciiCase(texturePath, "bakaunp/vaginalanalcanal2");
    }

    [[nodiscard]] constexpr bool IsBodyChangeNgCachedTexture(
        const std::string_view texturePath) noexcept
    {
        return ContainsIgnoreAsciiCase(texturePath, "bodychangeng\\cache\\") ||
            ContainsIgnoreAsciiCase(texturePath, "bodychangeng/cache/") ||
            ContainsIgnoreAsciiCase(texturePath, "bodychangerng\\cache\\") ||
            ContainsIgnoreAsciiCase(texturePath, "bodychangerng/cache/");
    }

    [[nodiscard]] constexpr bool IsKnownGenitalAnalNode(
        const std::string_view nodeName) noexcept
    {
        return EqualsIgnoreAsciiCase(nodeName, "3BA_Vagina") ||
            EqualsIgnoreAsciiCase(nodeName, "3BBB_Vagina") ||
            EqualsIgnoreAsciiCase(nodeName, "3BA_Anus") ||
            EqualsIgnoreAsciiCase(nodeName, "3BBB_Anus") ||
            EqualsIgnoreAsciiCase(nodeName, "BaseShapeVagina") ||
            EqualsIgnoreAsciiCase(nodeName, "BaseShapeAnus") ||
            EqualsIgnoreAsciiCase(nodeName, "BaseShapeCanal");
    }

    [[nodiscard]] constexpr bool IsCBBEGenitalAnal(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        // The current material path is authoritative when it still exposes a
        // known atlas. Node names remain the fallback after RaceMenu replaces
        // that path with Body Change NG's hashed runtime-cache alias.
        if (IsUNPGenitalAnalTexture(texturePath)) return false;
        if (IsCBBEGenitalAnalTexture(texturePath)) return true;
        // A non-empty foreign atlas is authoritative too. In particular,
        // some 3BA builds name a borrowed DW/UBE-anus mesh "3BA_Anus" even
        // though its UV is not the CBBE femalebody_etc atlas. Routing the CBBE
        // DDS into that shape both corrupts the material and used to abort the
        // entire native Skin Armor transaction.
        if (!texturePath.empty() && !IsBodyChangeNgCachedTexture(texturePath)) return false;
        return EqualsIgnoreAsciiCase(nodeName, "3BA_Vagina") ||
            EqualsIgnoreAsciiCase(nodeName, "3BBB_Vagina") ||
            EqualsIgnoreAsciiCase(nodeName, "3BA_Anus") ||
            EqualsIgnoreAsciiCase(nodeName, "3BBB_Anus");
    }

    [[nodiscard]] constexpr bool IsUNPGenitalAnal(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        if (IsCBBEGenitalAnalTexture(texturePath)) return false;
        if (IsUNPGenitalAnalTexture(texturePath)) return true;
        if (!texturePath.empty() && !IsBodyChangeNgCachedTexture(texturePath)) return false;
        // BHUNP BodySlide outputs observed in the base body and outfits use a
        // shared VaginalAnalCanal2 atlas on these three separate geometries.
        return EqualsIgnoreAsciiCase(nodeName, "BaseShapeVagina") ||
            EqualsIgnoreAsciiCase(nodeName, "BaseShapeAnus") ||
            EqualsIgnoreAsciiCase(nodeName, "BaseShapeCanal");
    }

    [[nodiscard]] constexpr bool IsGenitalAnal(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        // Recognition is intentionally broader than atlas compatibility.
        // Unsupported/foreign genital meshes must remain excluded from the
        // regular body route even when BCNG cannot safely assign them one of
        // its known CBBE/BHUNP atlas roles.
        return IsKnownGenitalAnalNode(nodeName) ||
            IsCBBEGenitalAnal(nodeName, texturePath) ||
            IsUNPGenitalAnal(nodeName, texturePath);
    }

    [[nodiscard]] constexpr bool IsMaleGenital(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        // SOS addon NIFs consistently expose malegenitals_* material paths.
        // Keep narrow node fallbacks for already overridden/cache paths. TRX
        // has shipped both Schlong and Shlong spellings; UBE SOS/TNG uses the
        // exact Penis node. These independent addon geometries must never be
        // mistaken for the regular body when their live path is a BCNG cache.
        return ContainsIgnoreAsciiCase(texturePath, "malegenitals_") ||
            ContainsIgnoreAsciiCase(nodeName, "malegenital") ||
            EqualsIgnoreAsciiCase(nodeName, "schlong") ||
            EqualsIgnoreAsciiCase(nodeName, "CBBE_Schlong") ||
            EqualsIgnoreAsciiCase(nodeName, "CBBE_Shlong") ||
            EqualsIgnoreAsciiCase(nodeName, "CBBE Schlong") ||
            EqualsIgnoreAsciiCase(nodeName, "Penis");
    }

    // A revealing outfit can keep its visible body copy on any biped slot,
    // rather than on the naked body's conventional slot 32 (or UBE slot 53).
    // Cross-slot discovery therefore needs stronger evidence than a generic
    // BaseShape name: accept an explicit body node/path while rejecting the
    // independent hand, foot, genital and anal atlases.
    [[nodiscard]] constexpr bool IsBodyGeometryCandidate(
        const std::string_view nodeName, const std::string_view texturePath = {}) noexcept
    {
        if (IsHandsOrFeetSlotPart(nodeName, texturePath) ||
            IsGenitalAnal(nodeName, texturePath) || IsMaleGenital(nodeName, texturePath)) {
            return false;
        }
        return ContainsIgnoreAsciiCase(texturePath, "body") ||
            ContainsIgnoreAsciiCase(nodeName, "body") ||
            ContainsIgnoreAsciiCase(nodeName, "torso") ||
            ContainsIgnoreAsciiCase(nodeName, "3ba") ||
            ContainsIgnoreAsciiCase(nodeName, "3bbb");
    }

    [[nodiscard]] constexpr bool Matches(
        const std::string_view nodeName, const BodySelection selection,
        const std::string_view texturePath = {}) noexcept
    {
        switch (selection) {
        case BodySelection::regular:
            return !IsGenitalAnal(nodeName, texturePath) &&
                !IsMaleGenital(nodeName, texturePath);
        case BodySelection::cbbeGenitalAnal: return IsCBBEGenitalAnal(nodeName, texturePath);
        case BodySelection::unpGenitalAnal: return IsUNPGenitalAnal(nodeName, texturePath);
        case BodySelection::maleGenitals: return IsMaleGenital(nodeName, texturePath);
        default: return true;
        }
    }
}
