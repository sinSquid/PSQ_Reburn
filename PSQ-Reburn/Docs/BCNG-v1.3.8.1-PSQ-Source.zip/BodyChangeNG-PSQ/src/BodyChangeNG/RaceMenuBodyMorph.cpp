#include "BodyChangeNG/RaceMenuBodyMorph.h"

#include "BodyChangeNG/ActorRegistry.h"
#include "BodyChangeNG/FrameTasks.h"
#include "BodyChangeNG/AsyncWorkGuards.h"
#include "BodyChangeNG/OutfitRefit.h"
#include "BodyChangeNG/RenderedOutfit.h"
#include "BodyChangeNG/BodyFamily.h"
#include "BodyChangeNG/BodyMorphPolicies.h"
#include "BodyChangeNG/BodyMorphWeight.h"
#include "BodyChangeNG/BodyRandomizationPolicy.h"
#include "BodyChangeNG/UbeGenitalRandomization.h"
#include "BodyChangeNG/UbeNippleRandomization.h"
#include "BodyChangeNG/UbeAnatomyRuntime.h"
#include "BodyChangeNG/BodyMorphKeys.h"
#include "BodyChangeNG/BodySliderEdit.h"
#include "BodyChangeNG/RaceMenuCompatibility.h"
#include "BodyChangeNG/PresetCatalog.h"
#include "BodyChangeNG/SliderName.h"
#include "BodyChangeNG/Settings.h"
#include "BodyChangeNG/NativeImGuiHost.h"
#include "BodyChangeNG/TemporaryBodyPreset.h"
#include "BodyChangeNG/PSQEquipmentRefreshPolicy.h"
#include <RE/R/RaceSexMenu.h>

#include <RE/B/BSVisit.h>
#include <RE/N/NiStringExtraData.h>
#include <SKSE/Logger.h>
#include <spdlog/spdlog.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <mutex>
#include <optional>
#include <random>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace
{
    void QueueActorTask(const RE::ActorHandle& handle,
        const bcn::appearance::WorkChannel channel, std::function<void()> work)
    {
        const auto actor = handle.get();
        if (!actor) return;
        if (channel == bcn::appearance::WorkChannel::bodyPreviewCleanup) {
            bcn::frame_tasks::QueueRestoration(actor->GetFormID(), std::move(work), 1U, channel);
        } else {
            bcn::frame_tasks::Queue(actor->GetFormID(), std::move(work), 1U,
                channel, channel == bcn::appearance::WorkChannel::bodyPreview);
        }
    }

    [[nodiscard]] constexpr bcn::appearance::WorkChannel ChannelForApplyMode(
        const bcn::racemenu::ApplyMode mode) noexcept
    {
        switch (mode) {
        case bcn::racemenu::ApplyMode::preview:
            return bcn::appearance::WorkChannel::bodyPreview;
        case bcn::racemenu::ApplyMode::outfit:
            return bcn::appearance::WorkChannel::outfitRefit;
        default:
            return bcn::appearance::WorkChannel::bodyCommit;
        }
    }
    namespace skee
    {
        class IPluginInterface
        {
        public:
            virtual ~IPluginInterface() = default;
            virtual std::uint32_t GetVersion() = 0;
            virtual void Revert() = 0;
        };

        class IInterfaceMap
        {
        public:
            virtual IPluginInterface* QueryInterface(const char* a_name) = 0;
            virtual bool AddInterface(const char* a_name, IPluginInterface* a_pluginInterface) = 0;
            virtual IPluginInterface* RemoveInterface(const char* a_name) = 0;
        };

        struct InterfaceExchangeMessage
        {
            enum : std::uint32_t { kExchangeInterface = 0x9E3779B9 };
            IInterfaceMap* interfaceMap{};
        };

        // Shared BodyMorph v4/v5 prefix through VisitActors. Early v4 (0.4.12)
        // does not yet declare ClearMorphCache. Do not include unused tail
        // methods just because a later header reports the same ABI version.
        class IBodyMorphInterface : public IPluginInterface
        {
        public:
            class MorphKeyVisitor { public: virtual void Visit(const char*, float) = 0; };
            class StringVisitor { public: virtual void Visit(const char*) = 0; };
            class ActorVisitor { public: virtual void Visit(RE::TESObjectREFR*) = 0; };
            class MorphValueVisitor { public: virtual void Visit(RE::TESObjectREFR*, const char*, const char*, float) = 0; };
            class MorphVisitor { public: virtual void Visit(RE::TESObjectREFR*, const char*) = 0; };

            virtual void SetMorph(RE::TESObjectREFR*, const char*, const char*, float) = 0;
            virtual float GetMorph(RE::TESObjectREFR*, const char*, const char*) = 0;
            virtual void ClearMorph(RE::TESObjectREFR*, const char*, const char*) = 0;
            virtual float GetBodyMorphs(RE::TESObjectREFR*, const char*) = 0;
            virtual void ClearBodyMorphNames(RE::TESObjectREFR*, const char*) = 0;
            virtual void VisitMorphs(RE::TESObjectREFR*, MorphVisitor&) = 0;
            virtual void VisitKeys(RE::TESObjectREFR*, const char*, MorphKeyVisitor&) = 0;
            virtual void VisitMorphValues(RE::TESObjectREFR*, MorphValueVisitor&) = 0;
            virtual void ClearMorphs(RE::TESObjectREFR*) = 0;
            virtual void ApplyVertexDiff(RE::TESObjectREFR*, RE::NiAVObject*, bool = false) = 0;
            virtual void ApplyBodyMorphs(RE::TESObjectREFR*, bool = true) = 0;
            virtual void UpdateModelWeight(RE::TESObjectREFR*, bool = false) = 0;
            // Not called: old v4 takes UInt32, newer sources use skee_u64.
            virtual void ReservedSetCacheLimit() = 0;
            virtual bool HasMorphs(RE::TESObjectREFR*) = 0;
            virtual std::uint32_t EvaluateBodyMorphs(RE::TESObjectREFR*) = 0;
            virtual bool HasBodyMorph(RE::TESObjectREFR*, const char*, const char*) = 0;
            virtual bool HasBodyMorphName(RE::TESObjectREFR*, const char*) = 0;
            virtual bool HasBodyMorphKey(RE::TESObjectREFR*, const char*) = 0;
            virtual void ClearBodyMorphKeys(RE::TESObjectREFR*, const char*) = 0;
            virtual void VisitStrings(StringVisitor&) = 0;
            virtual void VisitActors(ActorVisitor&) = 0;
        };
    }

    constexpr auto kCommittedKey = bcn::racemenu::keys::body;
    constexpr auto kPreviewKey = bcn::racemenu::keys::preview;
    constexpr auto kOutfitKey = bcn::racemenu::keys::outfit;
    constexpr auto kLegacyCommittedKey = bcn::racemenu::keys::legacyBody;
    constexpr auto kLegacyPreviewKey = bcn::racemenu::keys::legacyPreview;
    constexpr auto kLegacyOutfitKey = bcn::racemenu::keys::legacyOutfit;
    std::atomic<skee::IBodyMorphInterface*> g_bodyMorph{};
    std::atomic<skee::IInterfaceMap*> g_interfaceMap{};
    std::atomic_uint32_t g_version{};
    // One optional player-only external owner; no saved body snapshots or
    // pointers, and no per-frame polling. Request IDs never reset on load.
    constexpr auto kPSQTemporaryChannel = static_cast<bcn::appearance::WorkChannel>(0x50535101U);
    struct PSQTemporaryRequest final {
        RE::ActorHandle actor;
        RE::FormID base{};
        std::uint64_t epoch{};
        std::int32_t request{}, status{};
    };
    std::mutex g_psqTemporaryLock;
    std::optional<PSQTemporaryRequest> g_psqTemporary;
    std::atomic_int32_t g_nextPSQTemporaryRequest{};
    std::mutex g_initializeLock;
    struct BodyEditorSession final
    {
        RE::ActorHandle actor;
        std::uint64_t session{};
        std::string presetId;
        const char* key{};
        bcn::racemenu::editor::Transfer transfer;
        bcn::racemenu::editor::Values outfit;
    };
    std::mutex g_editorLock;
    std::optional<BodyEditorSession> g_bodyEditor;
    std::mutex g_previewLock;
    std::mutex g_selectionLock;
    std::mutex g_applyGenerationLock;
    RE::ActorHandle g_previewActor;
    std::uint64_t g_previewGeneration{};
    std::atomic_uint64_t g_nextApplyGeneration{ 1U };
    std::unordered_map<RE::FormID, std::string> g_currentPresetIds;
    std::unordered_map<std::uint64_t, std::uint64_t> g_applyGenerations;

    [[nodiscard]] std::uint64_t ApplyGenerationKey(
        const RE::FormID actorFormID, const bcn::racemenu::ApplyMode mode) noexcept
    {
        return (static_cast<std::uint64_t>(actorFormID) << 8U) |
            static_cast<std::uint8_t>(mode);
    }

    [[nodiscard]] std::uint64_t BeginApply(
        const RE::FormID actorFormID, const bcn::racemenu::ApplyMode mode)
    {
        std::scoped_lock lock(g_applyGenerationLock);
        const auto generation = g_nextApplyGeneration.fetch_add(1U, std::memory_order_relaxed);
        g_applyGenerations.insert_or_assign(ApplyGenerationKey(actorFormID, mode), generation);
        return generation;
    }

    [[nodiscard]] bool IsCurrentApply(const RE::FormID actorFormID,
        const bcn::racemenu::ApplyMode mode, const std::uint64_t generation)
    {
        std::scoped_lock lock(g_applyGenerationLock);
        const auto found = g_applyGenerations.find(ApplyGenerationKey(actorFormID, mode));
        return found != g_applyGenerations.end() && found->second == generation;
    }

    [[nodiscard]] std::uint64_t CurrentApplyGeneration(
        const RE::FormID actorFormID, const bcn::racemenu::ApplyMode mode)
    {
        std::scoped_lock lock(g_applyGenerationLock);
        const auto found = g_applyGenerations.find(ApplyGenerationKey(actorFormID, mode));
        return found == g_applyGenerations.end() ? 0U : found->second;
    }

    void InvalidateActorApplies(const RE::FormID actorFormID)
    {
        std::scoped_lock lock(g_applyGenerationLock);
        for (const auto mode : { bcn::racemenu::ApplyMode::preview,
                 bcn::racemenu::ApplyMode::commit, bcn::racemenu::ApplyMode::outfit }) {
            g_applyGenerations.insert_or_assign(ApplyGenerationKey(actorFormID, mode),
                g_nextApplyGeneration.fetch_add(1U, std::memory_order_relaxed));
        }
    }

    std::uint64_t InvalidateApply(const RE::FormID actorFormID, const bcn::racemenu::ApplyMode mode)
    {
        std::scoped_lock lock(g_applyGenerationLock);
        const auto generation = g_nextApplyGeneration.fetch_add(1U, std::memory_order_relaxed);
        g_applyGenerations.insert_or_assign(ApplyGenerationKey(actorFormID, mode), generation);
        return generation;
    }

    // A preview is layered above the last committed Body Change NG preset.
    // Collect that committed key first so the preview can cancel every old
    // slider that is absent from the newly previewed preset as well.
    class OwnedMorphCollector final : public skee::IBodyMorphInterface::MorphValueVisitor
    {
    public:
        explicit OwnedMorphCollector(const std::string_view key) : key_(key) {}

        void Visit(RE::TESObjectREFR*, const char* name, const char* key, const float value) override
        {
            if (name && *name && key && key_ == key) values.emplace_back(name, value);
        }

        std::vector<std::pair<std::string, float>> values;

    private:
        std::string_view key_;
    };

    class PreviewBaseCollector final : public skee::IBodyMorphInterface::MorphValueVisitor
    {
    public:
        PreviewBaseCollector(const bool preserve, const bool replaceOutfit) : base(preserve, replaceOutfit) {}
        void Visit(RE::TESObjectREFR*, const char* name, const char* key, const float value) override
        {
            base.Visit(name, key, value);
        }
        bcn::racemenu::keys::PreviewBase base;
    };

    void MigrateLegacyBodyChangeKeys(skee::IBodyMorphInterface& bodyMorph, RE::Actor* actor)
    {
        if (!actor) return;
        bool migrated{};
        if (bodyMorph.HasBodyMorphKey(actor, kLegacyCommittedKey)) {
            if (!bodyMorph.HasBodyMorphKey(actor, kCommittedKey)) {
                OwnedMorphCollector legacy{ kLegacyCommittedKey };
                bodyMorph.VisitMorphValues(actor, legacy);
                for (const auto& [name, value] : legacy.values) {
                    bodyMorph.SetMorph(actor, name.c_str(), kCommittedKey, value);
                }
            }
            bodyMorph.ClearBodyMorphKeys(actor, kLegacyCommittedKey);
            migrated = true;
        }
        for (const auto* key : { kLegacyPreviewKey, kLegacyOutfitKey }) {
            if (!bodyMorph.HasBodyMorphKey(actor, key)) continue;
            bodyMorph.ClearBodyMorphKeys(actor, key);
            migrated = true;
        }
        if (migrated) {
            SKSE::log::info("Body Change NG migrated legacy BodyChangerNG morph keys for actor {:08X}",
                actor->GetFormID());
        }
    }

    class MorphActorCollector final : public skee::IBodyMorphInterface::ActorVisitor
    {
    public:
        void Visit(RE::TESObjectREFR* reference) override
        {
            if (reference) actorFormIDs.push_back(reference->GetFormID());
        }

        std::vector<RE::FormID> actorFormIDs;
    };

    [[nodiscard]] skee::IBodyMorphInterface* Interface() noexcept
    {
        return g_bodyMorph.load(std::memory_order_acquire);
    }

    [[nodiscard]] bool IsCurrentPreview(const RE::ActorHandle& actorHandle, const std::uint64_t generation)
    {
        std::scoped_lock lock(g_previewLock);
        return g_previewGeneration == generation && g_previewActor == actorHandle;
    }

    [[nodiscard]] std::pair<RE::ActorHandle, std::uint64_t> BeginPreview(const RE::ActorHandle& actorHandle)
    {
        std::scoped_lock lock(g_previewLock);
        const auto previous = g_previewActor;
        g_previewActor = actorHandle;
        return { previous, ++g_previewGeneration };
    }

    [[nodiscard]] RE::ActorHandle CancelPreviewTracking(const RE::ActorHandle owner = {})
    {
        std::scoped_lock lock(g_previewLock);
        // Automatic work on a different NPC must not cancel the UI actor's
        // preview. Explicit UI close still cancels globally (empty owner).
        if (!bcn::async_work::MayCancelPreview(static_cast<bool>(owner), owner == g_previewActor)) return {};
        auto previous = g_previewActor;
        g_previewActor.reset();
        ++g_previewGeneration;
        return previous;
    }

    // PSQ API2 completion tickets certify only that a requested shared refresh
    // ran. They are never "clean" permissions for a later scenegraph state.
    struct PSQEquipmentRefresh final {
        RE::ActorHandle actor;
        RE::FormID base{};
        bcn::psq_equipment_refresh::Ticket ticket;
        std::int32_t status{};
        std::chrono::steady_clock::time_point started;
    };
    std::mutex g_psqEquipmentRefreshLock;
    std::optional<PSQEquipmentRefresh> g_psqEquipmentRefresh;
    std::atomic_int32_t g_nextPSQEquipmentRefresh{};

    void ResetPSQEquipmentRefresh()
    {
        std::scoped_lock lock(g_psqEquipmentRefreshLock);
        g_psqEquipmentRefresh.reset();
    }

    [[nodiscard]] std::optional<PSQEquipmentRefresh> CapturePSQEquipmentRefresh(
        const RE::ActorHandle& handle, const RE::FormID base,
        const std::uint64_t epoch, const std::uint64_t session)
    {
        const auto now = std::chrono::steady_clock::now();
        std::scoped_lock lock(g_psqEquipmentRefreshLock);
        if (!g_psqEquipmentRefresh || g_psqEquipmentRefresh->actor != handle ||
            g_psqEquipmentRefresh->base != base || g_psqEquipmentRefresh->status != 0 ||
            g_psqEquipmentRefresh->ticket.epoch != epoch ||
            g_psqEquipmentRefresh->ticket.session != session ||
            now - g_psqEquipmentRefresh->started >= std::chrono::seconds(2)) return {};
        return g_psqEquipmentRefresh;
    }

    void AcknowledgePSQEquipmentRefresh(const PSQEquipmentRefresh& captured,
        const std::uint64_t epoch, const std::uint64_t session)
    {
        std::scoped_lock lock(g_psqEquipmentRefreshLock);
        if (g_psqEquipmentRefresh && g_psqEquipmentRefresh->actor == captured.actor &&
            g_psqEquipmentRefresh->base == captured.base && g_psqEquipmentRefresh->status == 0 &&
            bcn::psq_equipment_refresh::CanAcknowledge(captured.ticket,
                g_psqEquipmentRefresh->ticket, epoch, session)) {
            g_psqEquipmentRefresh->status = 1;
        }
    }

    [[nodiscard]] bool QueueSharedVisibleMorphRefresh(RE::Actor* actor)
    {
        if (!actor || !bcn::frame_tasks::CurrentWorkAllowed()) return false;
        const auto handle = actor->GetHandle();
        const auto session = bcn::ActorRegistry::Get().SessionGeneration();
        return bcn::frame_tasks::Queue(actor->GetFormID(), [handle, session] {
            if (!bcn::frame_tasks::CurrentWorkAllowed() ||
                bcn::ActorRegistry::Get().SessionGeneration() != session) return;
            const auto resolved = handle.get();
            auto* current = Interface();
            if (!current || !resolved || !resolved->Is3DLoaded()) return;
            const auto epoch = bcn::frame_tasks::Epoch();
            const auto* base = resolved->GetActorBase();
            const auto baseID = base ? base->GetFormID() : 0U;
            // Snapshot the exact ticket BEFORE Apply. A newer request that is
            // submitted during Apply queues its own next job, never this ack.
            const auto captured = CapturePSQEquipmentRefresh(handle, baseID, epoch, session);
            // Keep the ordinary BCNG operation unchanged and on its original
            // latest-wins bodyMorphRefresh channel. This consumes ALL sources.
            current->ApplyBodyMorphs(resolved.get(), false);
            auto* ui = RE::UI::GetSingleton();
            const auto editing = ui && ui->IsMenuOpen(RE::RaceSexMenu::MENU_NAME);
            if (captured && !editing && bcn::frame_tasks::CurrentWorkAllowed()) {
                const auto currentEpoch = bcn::frame_tasks::Epoch();
                const auto currentSession = bcn::ActorRegistry::Get().SessionGeneration();
                const auto* currentBase = resolved->GetActorBase();
                if (currentBase && currentBase->GetFormID() == baseID && resolved->Is3DLoaded())
                    AcknowledgePSQEquipmentRefresh(*captured, currentEpoch, currentSession);
            }
        }, 1U, bcn::appearance::WorkChannel::bodyMorphRefresh);
    }

    void ApplyVisibleMorphs(skee::IBodyMorphInterface&, RE::Actor* actor, const bool /*deferUpdate*/)
    {
        [[maybe_unused]] const auto queued = QueueSharedVisibleMorphRefresh(actor);
    }

    void ClearPreviewNow(const RE::ActorHandle actorHandle)
    {
        if (!bcn::frame_tasks::CurrentWorkAllowed()) return;
        auto* bodyMorph = Interface();
        const auto actor = actorHandle.get();
        if (!bodyMorph || !actor || bcn::racemenu::HasActivePreview(actor.get())) return;
        const auto hadPreview = bodyMorph->HasBodyMorphKey(actor.get(), kPreviewKey) ||
            bodyMorph->HasBodyMorphKey(actor.get(), kLegacyPreviewKey);
        if (!bcn::frame_tasks::CurrentWorkAllowed()) return;
        bcn::racemenu::keys::ClearPreview(*bodyMorph, actor.get());
        // Stored morph keys belong to the reference even when its 3D is gone.
        // Only the visual refresh needs loaded geometry.
        if (hadPreview && actor->Is3DLoaded()) ApplyVisibleMorphs(*bodyMorph, actor.get(), false);
        // Display changes received during a body preview were intentionally
        // deferred. Re-evaluate the final SFS outfit once preview ends.
        if (actor->Is3DLoaded()) bcn::rendered_outfit::Request(actor.get());
    }

    void CancelPSQTemporaryRequest()
    {
        std::scoped_lock lock(g_psqTemporaryLock);
        g_psqTemporary.reset();
    }

    [[nodiscard]] bool PSQEditing(const RE::Actor* actor)
    {
        auto* ui = RE::UI::GetSingleton();
        return bcn::native_ui::IsOpen() ||
            (ui && ui->IsMenuOpen(RE::RaceSexMenu::MENU_NAME)) ||
            bcn::frame_tasks::HasPreview(actor->GetFormID()) ||
            bcn::frame_tasks::HasActorChannelWork(actor->GetFormID(), bcn::appearance::WorkChannel::bodyCommit) ||
            bcn::frame_tasks::HasActorChannelWork(actor->GetFormID(), bcn::appearance::WorkChannel::bodyPreview) ||
            bcn::racemenu::HasActivePreview(actor) ||
            bcn::racemenu::IsBodySliderEditing(actor);
    }

    [[nodiscard]] bool PSQCurrent(const RE::ActorHandle& handle, const RE::FormID base,
        const std::int32_t request, const std::uint64_t epoch)
    {
        if (!bcn::frame_tasks::IsCurrent(epoch) || !bcn::frame_tasks::CurrentWorkAllowed()) return false;
        const auto actor = handle.get();
        if (!actor || actor.get() != RE::PlayerCharacter::GetSingleton() ||
            !actor->GetActorBase() || actor->GetActorBase()->GetFormID() != base) return false;
        std::scoped_lock lock(g_psqTemporaryLock);
        return g_psqTemporary && g_psqTemporary->actor == handle &&
            bcn::temporary_body::Current(request, g_psqTemporary->request, epoch, g_psqTemporary->epoch);
    }

    void PSQComplete(const RE::ActorHandle& handle, const std::int32_t request,
        const std::uint64_t epoch, const std::int32_t status)
    {
        std::scoped_lock lock(g_psqTemporaryLock);
        if (g_psqTemporary && g_psqTemporary->actor == handle &&
            bcn::temporary_body::Current(request, g_psqTemporary->request, epoch, g_psqTemporary->epoch))
            g_psqTemporary->status = status;
    }

    class PSQNormalBodyCollector final : public skee::IBodyMorphInterface::MorphValueVisitor
    {
    public:
        void Visit(RE::TESObjectREFR*, const char* name, const char* key, const float value) override
        {
            if (!name || !*name || !key) return;
            // Leave normal outfit correction and every gameplay source active.
            // Editor keys are untouched, merely compensated while transformed.
            if (bcn::temporary_body::NormalBaseKey(key)) values[name] += value;
        }
        bcn::temporary_body::Values values;
    };

    // The only adapter body writer. It uses the same native interface and XML
    // units as normal BCNG, without entering its commit/preview/registry paths.
    void ApplyPSQTemporaryNow(const RE::ActorHandle handle, const RE::FormID base,
        const std::int32_t request, const std::uint64_t epoch,
        const std::optional<bcn::BodyPreset>& preset)
    {
        using namespace bcn::temporary_body;
        if (!PSQCurrent(handle, base, request, epoch)) return;
        auto* api = Interface();
        const auto actor = handle.get();
        if (!api || !actor) { PSQComplete(handle, request, epoch, unavailable); return; }
        if (PSQEditing(actor.get())) { PSQComplete(handle, request, epoch, editing); return; }
        if (preset && (!actor->Is3DLoaded() || bcn::Settings::Get().RemovalMode())) {
            PSQComplete(handle, request, epoch, applicationFailed); return;
        }
        if (preset) {
            if (preset->cachedContentHash != bcn::PresetCatalog::Get().ContentHash(preset->PersistentId()) ||
                preset->male != (actor->GetActorBase()->GetSex() != RE::SEX::kFemale) ||
                !bcn::body_family::Matches(bcn::body_family::PresetMask(preset->family, preset->male),
                    bcn::body_family::ResolveActor(actor.get()))) {
                PSQComplete(handle, request, epoch, invalidPreset); return;
            }
            // Probe only a reserved, non-TRI name, then remove that whole name.
            // Compensation is undefined for mean/max RaceMenu aggregation.
            if (!UsesAdditive(*api, actor.get())) {
                PSQComplete(handle, request, epoch, nonAdditive); return;
            }
            const auto weight = bcn::body_morph_weight::FromEnginePercent(actor->GetActorBase()->GetWeight());
            Values desired;
            for (const auto& slider : preset->sliders)
                desired.insert_or_assign(slider.name, slider.lowWeight + (slider.highWeight - slider.lowWeight) * weight);
            PSQNormalBodyCollector normal;
            api->VisitMorphValues(actor.get(), normal);
            const auto deltas = Deltas(desired, normal.values);
            if (!std::isfinite(weight) || !Finite(desired) || !Finite(normal.values) || !Finite(deltas)) {
                PSQComplete(handle, request, epoch, applicationFailed); return;
            }
            const auto status = Apply(*api, actor.get(), deltas,
                [&] { return PSQCurrent(handle, base, request, epoch); },
                [&] { api->ApplyBodyMorphs(actor.get(), false); });
            PSQComplete(handle, request, epoch, status);
        } else {
            const auto status = Clear(*api, actor.get(),
                [&] { return PSQCurrent(handle, base, request, epoch); },
                [&] { if (actor->Is3DLoaded()) api->ApplyBodyMorphs(actor.get(), false); });
            PSQComplete(handle, request, epoch, status);
        }
    }


    [[nodiscard]] bool IsNippleRefitSlider(const std::string_view sliderName)
    {
        std::string lowered{ sliderName };
        std::ranges::transform(lowered, lowered.begin(), [](const unsigned char character) {
            return static_cast<char>(std::tolower(character));
        });
        return lowered.contains("nipple") || lowered.contains("areola") || lowered.starts_with("nip");
    }

    void ApplyNow(RE::ActorHandle actorHandle, bcn::BodyPreset preset, const bcn::racemenu::ApplyMode mode,
                  const std::uint64_t applyGeneration, const std::uint64_t previewGeneration = 0,
                  const std::uint64_t outfitSignature = 0U,
                  const bcn::racemenu::UpdatePolicy updatePolicy =
                      bcn::racemenu::UpdatePolicy::synchronous)
    {
        const auto startedAt = std::chrono::steady_clock::now();
        if (!bcn::frame_tasks::CurrentWorkAllowed()) return;
        if (mode == bcn::racemenu::ApplyMode::preview && !IsCurrentPreview(actorHandle, previewGeneration)) {
            return;
        }
        auto* bodyMorph = Interface();
        if (!bodyMorph) {
            SKSE::log::error("Body Change NG could not apply '{}': RaceMenu BodyMorph is unavailable", preset.name);
            return;
        }
        if (preset.sliders.empty() && !preset.UsesBuildDefaults()) {
            SKSE::log::warn("Body Change NG could not apply '{}': the preset has no sliders", preset.name);
            return;
        }
        const auto actor = actorHandle.get();
        if (!actor) {
            SKSE::log::warn("Body Change NG could not apply '{}': the selected actor handle expired", preset.name);
            return;
        }
        if (!actor->Is3DLoaded()) {
            SKSE::log::warn("Body Change NG could not apply '{}' to actor {:08X}: 3D is not loaded", preset.name,
                            actor->GetFormID());
            return;
        }
        if (mode != bcn::racemenu::ApplyMode::outfit && bcn::racemenu::HasPSQTemporaryPreset(actor.get())) return;
        if (!IsCurrentApply(actor->GetFormID(), mode, applyGeneration)) {
            return;
        }

        const auto actorBase = actor->GetActorBase();
        if (preset.cachedContentHash != bcn::PresetCatalog::Get().ContentHash(preset.PersistentId())) {
            [[maybe_unused]] const auto refreshed = bcn::racemenu::QueueApply(actor.get(),
                preset.PersistentId(), mode, outfitSignature, updatePolicy);
            return;
        }
        if (!actorBase || preset.male != (actorBase->GetSex() != RE::SEX::kFemale) ||
            !bcn::body_family::Matches(bcn::body_family::PresetMask(preset.family, preset.male),
                bcn::body_family::ResolveActor(actor.get()))) return;
        const auto weight = bcn::body_morph_weight::FromEnginePercent(actorBase->GetWeight());
        const auto settings = bcn::Settings::Get().MorphOptions();
        const auto key = mode == bcn::racemenu::ApplyMode::preview ? kPreviewKey :
            mode == bcn::racemenu::ApplyMode::outfit ? kOutfitKey : kCommittedKey;
        // Replace BCNG and OBody's competing base-body/refit keys. Unrelated
        // keys survive by default. Preview must never clear persistent keys.
        if (!bcn::frame_tasks::CurrentWorkAllowed()) return;
        if (mode == bcn::racemenu::ApplyMode::commit) {
            bcn::racemenu::FinishBodySliderEdit(actor.get());
            bcn::racemenu::keys::BeginPresetCommit(*bodyMorph, actor.get(), settings.preserveOtherMorphs);
        }
        bcn::slider_name::Map<float> desiredMorphs;
        if (mode == bcn::racemenu::ApplyMode::outfit) {
            if (!bcn::rendered_outfit::ValidateApply(actor.get())) return;
            bodyMorph->ClearBodyMorphKeys(actor.get(), key);
            for (const auto& slider : preset.sliders) {
                // A named -Refit preset is still governed by the UI's
                // dependent nipple-refit switch.
                if (!settings.outfitNippleCorrection && IsNippleRefitSlider(slider.name)) continue;
                const auto value = slider.lowWeight + (slider.highWeight - slider.lowWeight) * weight;
                bodyMorph->SetMorph(actor.get(), slider.name.c_str(), key, value);
            }
        } else {
            if (mode == bcn::racemenu::ApplyMode::preview) {
                bodyMorph->ClearBodyMorphKeys(actor.get(), kPreviewKey);
                bodyMorph->ClearBodyMorphKeys(actor.get(), kLegacyPreviewKey);
            }
            desiredMorphs.reserve(preset.sliders.size() + 40U);
            for (const auto& slider : preset.sliders) {
                desiredMorphs.insert_or_assign(
                    slider.name, slider.lowWeight + (slider.highWeight - slider.lowWeight) * weight);
            }
        }
        if (mode == bcn::racemenu::ApplyMode::commit && actorBase && actorBase->GetSex() == RE::SEX::kFemale) {
            const auto presetFamily = bcn::body_family::PresetMask(preset.family, false);
            const auto femaleFamily = bcn::body_morph_policy::ResolveFemaleFamily(
                bcn::body_family::ResolveActor(actor.get()), presetFamily);
            const auto conventionalAnatomy = bcn::body_morph_policy::UsesConventionalAnatomyRecipe(femaleFamily);
            const auto write = [&](const char* name, float value) {
                desiredMorphs.insert_or_assign(name, value);
            };
            if (settings.nippleRandomization && conventionalAnatomy) {
                bcn::body_morph_policy::GenerateNippleMorphs(
                    bcn::body_morph_policy::OBodyChance, bcn::body_morph_policy::OBodyRandom, write);
            }
            if (settings.genitalRandomization && conventionalAnatomy) {
                bcn::body_morph_policy::GenerateGenitalMorphs(
                    bcn::body_morph_policy::OBodyChance, bcn::body_morph_policy::OBodyRandom, write);
            }
            if (femaleFamily == bcn::body_morph_policy::FemaleFamily::ube &&
                (settings.nippleRandomization || settings.genitalRandomization)) {
                if (settings.nippleRandomization) {
                    bcn::ube_nipple::Generate(
                        bcn::body_morph_policy::OBodyChance, bcn::body_morph_policy::OBodyRandom, write);
                }
                if (settings.genitalRandomization) {
                    // Only genital extras need TRI metadata. Nipple draws
                    // use the common UBE/Necoco dialect, with no file lookup.
                    const auto extras = bcn::ube_anatomy::SupportedExtras(actor.get());
                    static thread_local std::mt19937 random{ std::random_device{}() };
                    const auto shape = bcn::ube_genital::SelectShape(std::uniform_int_distribution<unsigned>(0U, 99U)(random));
                    const auto blend = std::uniform_real_distribution<float>(0.F, 1.F)(random);
                    bcn::ube_genital::Generate(shape, blend, extras, write);
                }
            }
        }
        if (mode != bcn::racemenu::ApplyMode::outfit) {
            bcn::slider_name::Map<float> replaced;
            if (mode == bcn::racemenu::ApplyMode::preview) {
                const auto plan = bcn::OutfitRefit::Get().Evaluate(actor.get(), &preset);
                const auto replaceOutfit = plan.action != bcn::OutfitRefit::Action::defer;
                PreviewBaseCollector collector(settings.preserveOtherMorphs, replaceOutfit);
                bodyMorph->VisitMorphValues(actor.get(), collector);
                replaced = std::move(collector.base.values);
                bcn::slider_name::Map<float> previewOutfit;
                if (plan.action == bcn::OutfitRefit::Action::named && plan.preset) {
                    for (const auto& slider : plan.preset->sliders) {
                        if (!settings.outfitNippleCorrection && IsNippleRefitSlider(slider.name)) continue;
                        previewOutfit.insert_or_assign(slider.name,
                            slider.lowWeight + (slider.highWeight - slider.lowWeight) * weight);
                    }
                } else if (plan.action == bcn::OutfitRefit::Action::procedural && !preset.male) {
                    const auto family = bcn::body_morph_policy::ResolveFemaleFamily(
                        bcn::body_family::ResolveActor(actor.get()),
                        bcn::body_family::PresetMask(preset.family, false));
                    bcn::body_morph_policy::GenerateOutfitMorphs(family, weight,
                        settings.outfitNippleCorrection,
                        [&](const char* name) {
                            const auto found = desiredMorphs.find(name);
                            return found == desiredMorphs.end() ? 0.0F : found->second;
                        },
                        [&](const char* name, const float value) { previewOutfit.insert_or_assign(name, value); });
                }
                for (const auto& [name, value] : previewOutfit) desiredMorphs[name] += value;
                // Also cancel old slider names absent from the selected XML,
                // including foreign-only names in non-preserving previews.
                for (const auto& [name, value] : replaced) desiredMorphs.try_emplace(name, 0.0F);
            }
            for (const auto& [name, desired] : desiredMorphs) {
                // Catalog values use XML / 100 (with legacy UNP inversion).
                // Commit never compensates against another mod. Only preview
                // is a temporary delta over unchanged persistent keys.
                const auto value = mode == bcn::racemenu::ApplyMode::preview ?
                    bcn::racemenu::PreviewPresetCorrection(desired, replaced[name]) : desired;
                bodyMorph->SetMorph(actor.get(), name.c_str(), key, value);
            }
        }
        // Both caller policies now share a coalesced, budgeted game-task
        // refresh. Key writes finish here; no SKEE partition job outlives that
        // later refresh's actor lease.
        ApplyVisibleMorphs(*bodyMorph, actor.get(),
            updatePolicy == bcn::racemenu::UpdatePolicy::deferred);
        if (mode == bcn::racemenu::ApplyMode::preview && !IsCurrentPreview(actorHandle, previewGeneration)) {
            ClearPreviewNow(actorHandle);
            return;
        }
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - startedAt).count();
        if (elapsed >= 16) {
            SKSE::log::warn(
                "Body Change NG body morph setup exceeded one 60-FPS frame: preset='{}' actor={:08X} sliders={} elapsed-ms={} update={}",
                preset.name, actor->GetFormID(), preset.sliders.size(), elapsed,
                updatePolicy == bcn::racemenu::UpdatePolicy::deferred ? "deferred" : "synchronous");
        }
        if (mode == bcn::racemenu::ApplyMode::commit) {
            if (!IsCurrentApply(actor->GetFormID(), mode, applyGeneration)) return;
            if (preset.cachedContentHash != bcn::PresetCatalog::Get().ContentHash(preset.PersistentId())) {
                [[maybe_unused]] const auto refreshed = bcn::racemenu::QueueApply(actor.get(),
                    preset.PersistentId(), mode, outfitSignature, updatePolicy);
                return;
            }
            {
                std::scoped_lock lock(g_selectionLock);
                g_currentPresetIds[actor->GetFormID()] = preset.PersistentId();
            }
            bcn::ActorRegistry::Get().MarkBodyApplied(actor.get(), preset.PersistentId(), false);
        } else if (mode == bcn::racemenu::ApplyMode::outfit) {
            bcn::ActorRegistry::Get().MarkOutfitApplied(actor.get(), outfitSignature);
        }
    }

    void ApplyProceduralOutfitNow(RE::ActorHandle actorHandle, const std::uint64_t outfitSignature)
    {
        auto* bodyMorph = Interface();
        const auto actor = actorHandle.get();
        if (!bodyMorph || !actor || !actor->Is3DLoaded()) return;

        const auto base = actor->GetActorBase();
        const auto weight = base ? bcn::body_morph_weight::FromEnginePercent(base->GetWeight()) : 0.0F;
        MigrateLegacyBodyChangeKeys(*bodyMorph, actor.get());

        bodyMorph->ClearBodyMorphKeys(actor.get(), kOutfitKey);
        // The procedural fallback below is authored for female breast/nipple
        // sliders. Male actors may still use an explicitly supplied male
        // outfit preset, but must never receive this female fallback.
        if (!base || base->GetSex() != RE::SEX::kFemale) {
            ApplyVisibleMorphs(*bodyMorph, actor.get(), true);
            bcn::ActorRegistry::Get().MarkOutfitApplied(actor.get(), outfitSignature);
            return;
        }
        bcn::body_family::Mask presetFamily{};
        if (const auto currentPresetId = bcn::racemenu::CurrentPresetId(actor.get())) {
            if (const auto currentPreset = bcn::PresetCatalog::Get().Find(*currentPresetId)) {
                presetFamily = bcn::body_family::PresetMask(currentPreset->family, false);
            }
        }
        const auto femaleFamily = bcn::body_morph_policy::ResolveFemaleFamily(
            bcn::body_family::ResolveActor(actor.get()), presetFamily);
        const auto settings = bcn::Settings::Get().MorphOptions();
        bcn::body_morph_policy::GenerateOutfitMorphs(femaleFamily, weight,
            settings.outfitNippleCorrection,
            [&](const char* name) { return bodyMorph->GetMorph(actor.get(), name, kCommittedKey); },
            [&](const char* name, const float value) { bodyMorph->SetMorph(actor.get(), name, kOutfitKey, value); });
        // Outfit correction is an automatic runtime operation. RaceMenu's
        // deferred partition update avoids blocking the frame that delivered
        // the equip/actor event while preserving the final morph keys.
        ApplyVisibleMorphs(*bodyMorph, actor.get(), true);
        bcn::ActorRegistry::Get().MarkOutfitApplied(actor.get(), outfitSignature);
    }
}

namespace bcn::racemenu
{
    void Initialize()
    {
        if (IsReady()) return;
        std::scoped_lock lock(g_initializeLock);
        if (IsReady()) return;

        auto* interfaceMap = g_interfaceMap.load(std::memory_order_acquire);
        if (!interfaceMap) {
            const auto* messaging = SKSE::GetMessagingInterface();
            if (!messaging) return;
            skee::InterfaceExchangeMessage message{};
            if (!messaging->Dispatch(skee::InterfaceExchangeMessage::kExchangeInterface,
                    &message, sizeof(message), "skee") || !message.interfaceMap) {
                SKSE::log::warn("Body Change NG could not exchange RaceMenu interfaces yet");
                return;
            }
            interfaceMap = message.interfaceMap;
            // The interface map belongs to the provider, not to BodyMorph.
            // Keep it available so overlays remain functional when BodyMorph
            // is disabled or its revision is rejected.
            g_interfaceMap.store(interfaceMap, std::memory_order_release);
        }
        const auto bodyMorph = static_cast<skee::IBodyMorphInterface*>(
            interfaceMap->QueryInterface("BodyMorph"));
        if (!bodyMorph) {
            SKSE::log::warn("Body Change NG could not obtain RaceMenu's BodyMorph interface");
            return;
        }
        const auto version = bodyMorph->GetVersion();
        const auto runtimeVersion = REL::Module::get().version();
        const auto branch = bcn::runtime::ResolveGameBranch(runtimeVersion);
        const auto abi = bcn::racemenu_compat::ResolveBodyMorphAbi(version, branch);
        if (abi == bcn::racemenu_compat::BodyMorphAbi::unsupported) {
            SKSE::log::warn(
                "Body Change NG rejected RaceMenu BodyMorph interface version {} on runtime {} ({})",
                version, runtimeVersion.string(), bcn::runtime::GameBranchLabel(branch));
            return;
        }
        g_version.store(version, std::memory_order_release);
        g_bodyMorph.store(bodyMorph, std::memory_order_release);
        if (bcn::racemenu_compat::UsesBodyMorphFallback(version)) {
            SKSE::log::warn("Body Change NG BodyMorph v{} is newer than audited: using the {} shared prefix; requires provider backward ABI compatibility",
                version, bcn::racemenu_compat::BodyMorphAbiLabel(abi));
        }
        SKSE::log::info("Body Change NG received RaceMenu {} on runtime {} ({})",
            bcn::racemenu_compat::BodyMorphAbiLabel(abi), runtimeVersion.string(),
            bcn::runtime::GameBranchLabel(branch));
    }

    void ResetSessionState()
    {
        CancelPSQTemporaryRequest();
        ResetPSQEquipmentRefresh();
        bcn::ube_anatomy::ClearSupportCache();
        {
            // The old world's SKEE records are reverted by its provider.
            // Never write through a previous-world actor during load/revert.
            std::scoped_lock lock(g_editorLock);
            g_bodyEditor.reset();
        }
        {
            std::scoped_lock lock(g_applyGenerationLock);
            g_applyGenerations.clear();
        }
        {
            std::scoped_lock lock(g_selectionLock);
            g_currentPresetIds.clear();
        }
        [[maybe_unused]] const auto previousPreview = CancelPreviewTracking();
    }

    std::int32_t RequestPSQEquipmentMorphRefresh(RE::Actor* actor)
    {
        if (!actor || actor != RE::PlayerCharacter::GetSingleton() || !actor->GetActorBase() ||
            !frame_tasks::Active() || !IsReady() || Settings::Get().RemovalMode()) return -1;
        const auto handle = actor->GetHandle();
        const auto base = actor->GetActorBase()->GetFormID();
        const auto epoch = frame_tasks::Epoch();
        const auto session = ActorRegistry::Get().SessionGeneration();
        const auto now = std::chrono::steady_clock::now();
        std::int32_t request;
        {
            std::scoped_lock lock(g_psqEquipmentRefreshLock);
            const auto previous = g_nextPSQEquipmentRefresh.load(std::memory_order_relaxed);
            if (previous >= INT32_MAX) return -1;
            request = previous + 1;
            g_nextPSQEquipmentRefresh.store(request, std::memory_order_relaxed);
            g_psqEquipmentRefresh = PSQEquipmentRefresh{ handle, base,
                { request, epoch, session }, 0, now };
        }
        if (!QueueSharedVisibleMorphRefresh(actor)) {
            std::scoped_lock lock(g_psqEquipmentRefreshLock);
            if (g_psqEquipmentRefresh && g_psqEquipmentRefresh->ticket.id == request)
                g_psqEquipmentRefresh->status = -1;
            return -1;
        }
        return request;
    }

    std::int32_t PSQEquipmentMorphRefreshStatus(RE::Actor* actor, const std::int32_t request)
    {
        if (!actor || actor != RE::PlayerCharacter::GetSingleton() || !actor->GetActorBase() ||
            request <= 0 || !frame_tasks::Active()) return -1;
        const auto handle = actor->GetHandle();
        const auto base = actor->GetActorBase()->GetFormID();
        const auto epoch = frame_tasks::Epoch();
        const auto session = ActorRegistry::Get().SessionGeneration();
        const auto now = std::chrono::steady_clock::now();
        // Query the queue OUTSIDE our request lock (no lock-order inversion).
        const auto work = frame_tasks::HasActorChannelWork(actor->GetFormID(),
            appearance::WorkChannel::bodyMorphRefresh);
        std::scoped_lock lock(g_psqEquipmentRefreshLock);
        if (!g_psqEquipmentRefresh || g_psqEquipmentRefresh->actor != handle ||
            g_psqEquipmentRefresh->base != base ||
            !bcn::psq_equipment_refresh::CanAcknowledge(
                { request, epoch, session }, g_psqEquipmentRefresh->ticket, epoch, session)) return -1;
        if (g_psqEquipmentRefresh->status == 1) return 1;
        if (g_psqEquipmentRefresh->status < 0 || !work ||
            now - g_psqEquipmentRefresh->started >= std::chrono::seconds(2)) {
            g_psqEquipmentRefresh->status = -1;
            return -1;
        }
        return 0;
    }

    bool IsReady() noexcept
    {
        return Interface() != nullptr;
    }

    std::uint32_t Version() noexcept
    {
        return g_version.load(std::memory_order_acquire);
    }

    void* QueryInterface(const char* name) noexcept
    {
        if (!name || name[0] == '\0') return nullptr;
        auto* interfaceMap = g_interfaceMap.load(std::memory_order_acquire);
        if (!interfaceMap) {
            Initialize();
            interfaceMap = g_interfaceMap.load(std::memory_order_acquire);
        }
        return interfaceMap ? interfaceMap->QueryInterface(name) : nullptr;
    }

    std::optional<std::string> CurrentPresetId(const RE::Actor* actor)
    {
        if (!actor) return std::nullopt;
        if (!actor->Is3DLoaded()) return bcn::ActorRegistry::Get().SelectedBodyId(actor);
        {
            std::scoped_lock lock(g_selectionLock);
            const auto found = g_currentPresetIds.find(actor->GetFormID());
            if (found != g_currentPresetIds.end()) return found->second.empty() ?
                std::nullopt : std::optional<std::string>(found->second);
        }
        if (const auto state = bcn::ActorRegistry::Get().Snapshot(actor);
            state && state->body.selection.useDefault) return std::nullopt;
        if (const auto selected = bcn::ActorRegistry::Get().SelectedBodyId(actor)) return selected;
        return bcn::ActorRegistry::Get().AppliedBodyId(actor);
    }

    bool IsBodySliderEditing(const RE::Actor* actor)
    {
        if (!actor) return false;
        std::scoped_lock lock(g_editorLock);
        return g_bodyEditor && g_bodyEditor->session == ActorRegistry::Get().SessionGeneration() &&
            g_bodyEditor->actor.get().get() == actor;
    }

    [[nodiscard]] bool UsesAdditiveBodyMorphs(skee::IBodyMorphInterface& api, RE::Actor* actor)
    {
        // Read the actual provider's aggregation policy through its common
        // public prefix. The reserved name has no TRI; remove the entire name
        // afterwards, including its map, even on early-v4 mean-mode providers.
        constexpr auto probe = "BodyChangeNG:EditorModeProbe";
        api.SetMorph(actor, probe, keys::editorBaseline, .25F);
        api.SetMorph(actor, probe, keys::editorOffset, .75F);
        const auto combined = api.GetBodyMorphs(actor, probe);
        api.ClearBodyMorphNames(actor, probe);
        return std::isfinite(combined) && std::abs(combined - 1.F) < .00001F;
    }

    bool BeginBodySliderEdit(RE::Actor* actor)
    {
        auto* bodyMorph = Interface();
        auto* player = RE::PlayerCharacter::GetSingleton();
        if (!actor || actor != player || !bodyMorph || !actor->Is3DLoaded() ||
            Settings::Get().RemovalMode() || HasPSQTemporaryPreset(actor)) return false;
        const auto presetId = CurrentPresetId(actor);
        const auto preset = presetId ? PresetCatalog::Get().Find(*presetId) : std::nullopt;
        if (!preset || ActorRegistry::Get().NeedsBodyApply(actor, *presetId, false)) return false;
        const auto family = body_family::PresetMask(preset->family, preset->male);
        const auto* key = editor::Key(family);
        if (!key || !body_family::Matches(family, body_family::ResolveActor(actor))) return false;
        std::scoped_lock lock(g_editorLock);
        if (g_bodyEditor) return g_bodyEditor->actor.get().get() == actor;
        if (!UsesAdditiveBodyMorphs(*bodyMorph, actor)) {
            SKSE::log::warn("BCNG body slider editing requires additive RaceMenu iBodyMorphMode=0; the current provider is non-additive");
            return false;
        }
        MigrateLegacyBodyChangeKeys(*bodyMorph, actor);
        BodyEditorSession next{ actor->GetHandle(), ActorRegistry::Get().SessionGeneration(),
            *presetId, key };
        const auto collect = [&](const char* layer) {
            OwnedMorphCollector visitor{layer};
            bodyMorph->VisitMorphValues(actor, visitor);
            editor::Values values;
            for (const auto& [name, value] : visitor.values) values.insert_or_assign(name, value);
            return values;
        };
        next.transfer.body = collect(kCommittedKey);
        next.transfer.originalEditor = collect(key);
        next.outfit = collect(kOutfitKey);
        const auto editable = next.transfer.Editable();
        if (!editor::Finite(next.transfer.body) || !editor::Finite(next.transfer.originalEditor) ||
            !editor::Finite(editable)) return false;
        // Slider requests read only their script's key. Offset our existing
        // body once, while displaying its values through that key. Keep the
        // baseline and inverse as owned SKEE layers: if its save callback runs
        // before ours, load can finish the transfer without a second XML apply.
        [[maybe_unused]] const auto oldPreview = CancelPreviewTracking(actor->GetHandle());
        keys::ClearPreview(*bodyMorph, actor);
        bodyMorph->ClearBodyMorphKeys(actor, kOutfitKey);
        bodyMorph->ClearBodyMorphKeys(actor, key);
        bodyMorph->ClearBodyMorphKeys(actor, keys::editorBaseline);
        bodyMorph->ClearBodyMorphKeys(actor, keys::editorOffset);
        for (const auto& [name, value] : next.transfer.originalEditor)
            bodyMorph->SetMorph(actor, name.c_str(), keys::editorBaseline, value);
        for (const auto& [name, value] : editable) {
            bodyMorph->SetMorph(actor, name.c_str(), keys::editorOffset, -value);
            bodyMorph->SetMorph(actor, name.c_str(), key, value);
        }
        // A zero-valued unknown name has no TRI effect; it marks an empty
        // Zeroed Sliders session too. SKEE retains and serializes zero keys.
        bodyMorph->SetMorph(actor, editor::Marker(key), keys::editorOffset, 0.F);
        g_bodyEditor = std::move(next);
        return true;
    }

    void FinishBodySliderEdit(RE::Actor* actor)
    {
        auto* bodyMorph = Interface();
        if (!actor || !bodyMorph) return;
        std::optional<BodyEditorSession> finished;
        {
            std::scoped_lock lock(g_editorLock);
            if (!g_bodyEditor) {
                if (actor != RE::PlayerCharacter::GetSingleton() ||
                    !bodyMorph->HasBodyMorphKey(actor, keys::editorOffset)) return;
                // Recover a provider snapshot saved during editing. Its own
                // baseline keys and edited key belong to the same SKEE record,
                // so callback order never mixes an old preset with new edits.
                const char* key{};
                for (const auto& info : editor::kKeys) {
                    if (!bodyMorph->HasBodyMorph(actor, info.marker, keys::editorOffset)) continue;
                    if (key) return; // Conflicting recovery markers are unverified.
                    key = info.key;
                }
                if (!key) return;
                const auto appliedId = ActorRegistry::Get().AppliedBodyId(actor);
                const auto id = appliedId ? appliedId : CurrentPresetId(actor);
                BodyEditorSession recovered{actor->GetHandle(), ActorRegistry::Get().SessionGeneration(),
                    id.value_or(std::string{}), key};
                const auto collect = [&](const char* layer) {
                    OwnedMorphCollector collector{layer};
                    bodyMorph->VisitMorphValues(actor, collector);
                    editor::Values values;
                    for (const auto& [name, value] : collector.values) values.insert_or_assign(name, value);
                    return values;
                };
                recovered.transfer.body = collect(kCommittedKey);
                recovered.transfer.originalEditor = collect(keys::editorBaseline);
                if (!editor::Finite(recovered.transfer.body) || !editor::Finite(recovered.transfer.originalEditor)) return;
                g_bodyEditor = std::move(recovered);
            }
            if (g_bodyEditor->actor.get().get() != actor) return;
            if (g_bodyEditor->session != ActorRegistry::Get().SessionGeneration()) {
                g_bodyEditor.reset();
                return;
            }
            OwnedMorphCollector visitor{g_bodyEditor->key};
            bodyMorph->VisitMorphValues(actor, visitor);
            editor::Values edited;
            for (const auto& [name, value] : visitor.values) edited.insert_or_assign(name, value);
            auto committed = g_bodyEditor->transfer.Committed(edited);
            if (!editor::Finite(edited) || !editor::Finite(committed)) {
                committed = g_bodyEditor->transfer.body;
                SKSE::log::warn("BCNG rejected non-finite RaceMenu body slider edits for actor {:08X}",
                    actor->GetFormID());
            }
            bodyMorph->ClearBodyMorphKeys(actor, keys::editorBaseline);
            bodyMorph->ClearBodyMorphKeys(actor, keys::editorOffset);
            bodyMorph->ClearBodyMorphKeys(actor, g_bodyEditor->key);
            for (const auto& [name, value] : g_bodyEditor->transfer.originalEditor)
                bodyMorph->SetMorph(actor, name.c_str(), g_bodyEditor->key, value);
            bodyMorph->ClearBodyMorphKeys(actor, kCommittedKey);
            for (const auto& [name, value] : committed)
                bodyMorph->SetMorph(actor, name.c_str(), kCommittedKey, value);
            // Keep the previous clothing contribution until the normal outfit
            // policy recomputes it; the editor never stores clothing in body.
            for (const auto& [name, value] : g_bodyEditor->outfit)
                bodyMorph->SetMorph(actor, name.c_str(), kOutfitKey, value);
            finished = std::move(g_bodyEditor);
            g_bodyEditor.reset();
        }
        if (CurrentPresetId(actor) == std::optional{finished->presetId}) {
            ActorRegistry::Get().MarkBodyApplied(actor, finished->presetId, false);
            ActorRegistry::Get().InvalidateOutfit(actor);
        }
    }

    std::optional<bool> LiveBodyChangeStateMatches(const RE::Actor* actor, const bool expectDefault)
    {
        auto* bodyMorph = Interface();
        if (!actor || !bodyMorph) return std::nullopt;
        if (IsBodySliderEditing(actor)) return true;
        auto* reference = const_cast<RE::Actor*>(actor);
        FinishBodySliderEdit(reference);
        const auto hasCommitted = bodyMorph->HasBodyMorphKey(reference, kCommittedKey) ||
            bodyMorph->HasBodyMorphKey(reference, kLegacyCommittedKey);
        const auto hasOBody = bodyMorph->HasBodyMorphKey(reference, keys::obody) ||
            bodyMorph->HasBodyMorphKey(reference, keys::oclothe);
        if (!expectDefault) {
            // An empty UBE Zeroed XML deliberately writes no morph key. Its
            // saved selection is valid when the competing base keys are gone.
            const auto id = CurrentPresetId(actor);
            const auto preset = id ? PresetCatalog::Get().Find(*id) : std::nullopt;
            const auto usesBuildDefaults = preset && preset->UsesBuildDefaults();
            return (usesBuildDefaults || hasCommitted) && !hasOBody;
        }
        // A Default base body can legitimately wear an independent refit.
        // Explicit Default/reset still clears every owned layer; automatic
        // base verification must not mistake clothing for a changed preset.
        const auto hasBaseOrPreview = hasCommitted ||
            bodyMorph->HasBodyMorphKey(reference, kPreviewKey) ||
            bodyMorph->HasBodyMorphKey(reference, kLegacyPreviewKey);
        return !hasBaseOrPreview && !hasOBody;
    }

    void QueueVerifySavedBody(RE::Actor* actor)
    {
        if (!actor || !ActorRegistry::Get().Snapshot(actor)) return;
        const auto handle = actor->GetHandle();
        frame_tasks::Queue(actor->GetFormID(), [handle] {
            const auto resolved = handle.get();
            auto* actor = resolved.get();
            if (!actor || !actor->Is3DLoaded() || !IsReady() ||
                frame_tasks::HasPreview(actor->GetFormID()) || HasActivePreview(actor) || IsBodySliderEditing(actor) ||
                frame_tasks::HasActorChannelWork(actor->GetFormID(), appearance::WorkChannel::bodyCommit) ||
                frame_tasks::HasActorChannelWork(actor->GetFormID(), appearance::WorkChannel::bodyPreviewCleanup)) return;
            const auto state = ActorRegistry::Get().Snapshot(actor);
            if (!state) return;
            const auto& selection = state->body.selection;
            if (!selection.useDefault && selection.selectedId.empty()) return;
            if (!ActorRegistry::Get().NeedsBodyApply(actor, selection.selectedId, selection.useDefault)) return;
            if (selection.useDefault) {
                QueueClearBodyChangeMorphs(actor);
                OutfitRefit::Get().ProcessActor(actor);
            } else if (QueueApply(actor, selection.selectedId, ApplyMode::commit, 0U,
                           UpdatePolicy::deferred) == ApplyResult::queued) {
                // Restore the outfit layer through its normal policy after
                // the base layer is queued; never reroll distribution rules.
                OutfitRefit::Get().ProcessActor(actor);
            }
        }, 2U, appearance::WorkChannel::bodyVerify);
    }

    bool HasOutfitCorrection(const RE::Actor* actor)
    {
        auto* bodyMorph = Interface();
        if (!actor || !bodyMorph) return false;
        auto* reference = const_cast<RE::Actor*>(actor);
        return bodyMorph->HasBodyMorphKey(reference, kOutfitKey) ||
            bodyMorph->HasBodyMorphKey(reference, kLegacyOutfitKey);
    }

    bool HasActivePreview(const RE::Actor* actor)
    {
        std::scoped_lock lock(g_previewLock);
        return actor && g_previewActor.get().get() == actor;
    }

    bool HasPSQTemporaryPreset(const RE::Actor* actor)
    {
        auto* api = Interface();
        if (!actor || actor != RE::PlayerCharacter::GetSingleton()) return false;
        if (api && api->HasBodyMorphKey(const_cast<RE::Actor*>(actor), temporary_body::key)) return true;
        bool pending{};
        {
            std::scoped_lock lock(g_psqTemporaryLock);
            pending = g_psqTemporary && g_psqTemporary->actor.get().get() == actor &&
                g_psqTemporary->epoch == frame_tasks::Epoch() &&
                g_psqTemporary->status == temporary_body::pending;
        }
        // The acceptance/queue gap is locked. A detached/cancelled job must
        // not leave the normal body editor blocked forever without a layer.
        return pending && frame_tasks::HasActorChannelWork(actor->GetFormID(), kPSQTemporaryChannel);
    }

    std::int32_t QueuePSQTemporaryPreset(RE::Actor* actor, std::string presetId, const bool clear)
    {
        using namespace temporary_body;
        if (!actor || actor != RE::PlayerCharacter::GetSingleton() || !actor->GetActorBase())
            return invalidActor;
        if (!IsReady() || !frame_tasks::Active() || !SKSE::GetTaskInterface()) return unavailable;
        if (PSQEditing(actor)) return editing;
        if (!clear && (!actor->Is3DLoaded() || Settings::Get().RemovalMode())) return unavailable;
        std::optional<BodyPreset> preset;
        if (!clear) {
            preset = PresetCatalog::Get().Find(presetId);
            if (!preset || (preset->sliders.empty() && !preset->UsesBuildDefaults()) ||
                preset->male != (actor->GetActorBase()->GetSex() != RE::SEX::kFemale) ||
                !body_family::Matches(body_family::PresetMask(preset->family, preset->male),
                    body_family::ResolveActor(actor))) return invalidPreset;
        }
        const auto handle = actor->GetHandle();
        const auto base = actor->GetActorBase()->GetFormID();
        const auto epoch = frame_tasks::Epoch();
        // Serialize acceptance and queue submission together. Otherwise an
        // older caller could enqueue after a newer one and coalesce its work.
        std::scoped_lock lock(g_psqTemporaryLock);
        const auto previous = g_nextPSQTemporaryRequest.load(std::memory_order_relaxed);
        if (previous == std::numeric_limits<std::int32_t>::max()) return unavailable;
        const auto request = previous + 1;
        g_nextPSQTemporaryRequest.store(request, std::memory_order_relaxed);
        g_psqTemporary = PSQTemporaryRequest{ handle, base, epoch, request, pending };
        auto work = [handle, base, request, epoch, preset = std::move(preset)] {
            ApplyPSQTemporaryNow(handle, base, request, epoch, preset);
        };
        // A parked clear survives detach and waits out RaceMenu; a later apply
        // replaces only this exact owner's channel and invalidates its token.
        const auto queued = clear ? frame_tasks::QueueRestoration(actor->GetFormID(),
            std::move(work), 1U, kPSQTemporaryChannel) :
            frame_tasks::Queue(actor->GetFormID(), std::move(work), 1U, kPSQTemporaryChannel, true, true);
        if (!queued) {
            g_psqTemporary->status = unavailable;
            return unavailable;
        }
        return request;
    }

    std::int32_t PSQTemporaryRequestStatus(const RE::Actor* actor, const std::int32_t request)
    {
        using namespace temporary_body;
        if (!actor || actor != RE::PlayerCharacter::GetSingleton() || !actor->GetActorBase()) return invalidActor;
        PSQTemporaryRequest snapshot;
        {
            std::scoped_lock lock(g_psqTemporaryLock);
            if (!g_psqTemporary || g_psqTemporary->actor.get().get() != actor ||
                g_psqTemporary->base != actor->GetActorBase()->GetFormID() ||
                !Current(request, g_psqTemporary->request, g_psqTemporary->epoch, frame_tasks::Epoch()))
                return superseded;
            snapshot = *g_psqTemporary;
        }
        if (!frame_tasks::IsCurrent(snapshot.epoch)) return superseded;
        if (snapshot.status == pending &&
            !frame_tasks::HasActorChannelWork(actor->GetFormID(), kPSQTemporaryChannel))
            return applicationFailed;
        if (snapshot.status == applied && !HasPSQTemporaryPreset(actor)) return applicationFailed;
        return snapshot.status;
    }

    void ForgetActorState(const std::uint32_t actorFormID)
    {
        if (actorFormID == 0) return;
        {
            std::scoped_lock lock(g_selectionLock);
            g_currentPresetIds.erase(actorFormID);
        }
        {
            std::scoped_lock lock(g_applyGenerationLock);
            for (const auto mode : { ApplyMode::preview, ApplyMode::commit, ApplyMode::outfit }) {
                g_applyGenerations.erase(ApplyGenerationKey(actorFormID, mode));
            }
        }
    }

    ApplyResult QueueApply(RE::Actor* actor, std::string presetId, const ApplyMode mode,
        const std::uint64_t outfitSignature, const UpdatePolicy updatePolicy)
    {
        if (!bcn::frame_tasks::Active()) return ApplyResult::noTaskInterface;
        if (!IsReady()) return ApplyResult::unavailable;
        if (!actor) return ApplyResult::invalidActor;
        // An external temporary shape must never be captured by a UI commit,
        // preview or body editor as the player's normal-form body.
        if (mode != ApplyMode::outfit && HasPSQTemporaryPreset(actor)) return ApplyResult::psqTemporaryPresetActive;
        const auto found = PresetCatalog::Get().Find(presetId, mode == ApplyMode::outfit);
        if (!found) return ApplyResult::missingPreset;
        if (found->sliders.empty() && !found->UsesBuildDefaults()) return ApplyResult::emptyPreset;
        const auto* base = actor->GetActorBase();
        if (!base) return ApplyResult::invalidActor;
        const auto actorMale = base->GetSex() != RE::SEX::kFemale;
        if (found->male != actorMale) return ApplyResult::incompatibleSex;
        if (!bcn::body_family::Matches(
            bcn::body_family::PresetMask(found->family, found->male),
            bcn::body_family::ResolveActor(actor))) return ApplyResult::incompatibleBodyFamily;
        // The caller records accepted commit intent in ActorRegistry. No
        // geometry, morph key or preview is touched for an unloaded actor;
        // the normal attach queue validates and applies that saved intent.
        if (!actor->Is3DLoaded()) return mode == ApplyMode::commit ?
            ApplyResult::queued : ApplyResult::actor3DUnavailable;
        const auto actorHandle = actor->GetHandle();
        const auto applyGeneration = BeginApply(actor->GetFormID(), mode);
        if (const auto* tasks = SKSE::GetTaskInterface()) {
            if (mode == ApplyMode::commit) {
                // Commit clears the outfit key even if the preset ID did not
                // change. Its completion signature must not suppress repaint.
                bcn::ActorRegistry::Get().InvalidateOutfit(actor);
                // Reflect the newest accepted user choice in the list
                // immediately. Do this only after the game task interface was
                // acquired so a failed submission cannot show a false current
                // preset.
                std::scoped_lock lock(g_selectionLock);
                g_currentPresetIds[actor->GetFormID()] = found->PersistentId();
            }
            auto preset = *found;
            const auto session = bcn::ActorRegistry::Get().SessionGeneration();
            if (mode == ApplyMode::preview) {
                const auto [previousActor, generation] = BeginPreview(actorHandle);
                if (previousActor && previousActor != actorHandle) {
                    QueueActorTask(previousActor,
                        bcn::appearance::WorkChannel::bodyPreviewCleanup, [previousActor, session] {
                        if (bcn::ActorRegistry::Get().SessionGeneration() == session) ClearPreviewNow(previousActor);
                    });
                }
                QueueActorTask(actorHandle, bcn::appearance::WorkChannel::bodyPreview,
                    [actorHandle, preset = std::move(preset), applyGeneration, generation,
                    updatePolicy] mutable {
                    ApplyNow(actorHandle, std::move(preset), ApplyMode::preview, applyGeneration,
                        generation, 0U, updatePolicy);
                });
            } else {
                const auto previousActor = mode == ApplyMode::commit ? CancelPreviewTracking(actorHandle) : RE::ActorHandle{};
                if (previousActor && previousActor != actorHandle) {
                    QueueActorTask(previousActor,
                        bcn::appearance::WorkChannel::bodyPreviewCleanup, [previousActor, session] {
                        if (bcn::ActorRegistry::Get().SessionGeneration() == session) ClearPreviewNow(previousActor);
                    });
                }
                QueueActorTask(actorHandle, ChannelForApplyMode(mode),
                    [actorHandle, preset = std::move(preset), mode, applyGeneration,
                    outfitSignature, updatePolicy] mutable {
                    ApplyNow(actorHandle, std::move(preset), mode, applyGeneration, 0U,
                        outfitSignature, updatePolicy);
                });
            }
            return ApplyResult::queued;
        }
        return ApplyResult::noTaskInterface;
    }

    ApplyResult QueuePreviewDefault(RE::Actor* actor)
    {
        if (!bcn::frame_tasks::Active()) return ApplyResult::noTaskInterface;
        if (!IsReady()) return ApplyResult::unavailable;
        if (!actor) return ApplyResult::invalidActor;
        if (HasPSQTemporaryPreset(actor)) return ApplyResult::psqTemporaryPresetActive;
        if (!actor->Is3DLoaded()) return ApplyResult::actor3DUnavailable;
        if (!SKSE::GetTaskInterface()) return ApplyResult::noTaskInterface;

        const auto actorHandle = actor->GetHandle();
        const auto applyGeneration = BeginApply(actor->GetFormID(), ApplyMode::preview);
        const auto [previousActor, previewGeneration] = BeginPreview(actorHandle);
        const auto session = bcn::ActorRegistry::Get().SessionGeneration();
        if (previousActor && previousActor != actorHandle) {
            QueueActorTask(previousActor,
                bcn::appearance::WorkChannel::bodyPreviewCleanup, [previousActor, session] {
                    if (bcn::ActorRegistry::Get().SessionGeneration() == session) {
                        ClearPreviewNow(previousActor);
                    }
                });
        }
        QueueActorTask(actorHandle, bcn::appearance::WorkChannel::bodyPreview,
            [actorHandle, applyGeneration, previewGeneration, session] {
                if (bcn::ActorRegistry::Get().SessionGeneration() != session ||
                    !IsCurrentPreview(actorHandle, previewGeneration)) return;
                auto* bodyMorph = Interface();
                const auto resolved = actorHandle.get();
                if (!bodyMorph || !resolved || !resolved->Is3DLoaded() || HasPSQTemporaryPreset(resolved.get()) ||
                    !IsCurrentApply(resolved->GetFormID(), ApplyMode::preview,
                        applyGeneration)) return;

                bodyMorph->ClearBodyMorphKeys(resolved.get(), kPreviewKey);
                bodyMorph->ClearBodyMorphKeys(resolved.get(), kLegacyPreviewKey);
                PreviewBaseCollector collector(true, true);
                bodyMorph->VisitMorphValues(resolved.get(), collector);
                for (const auto& [name, value] : collector.base.values) {
                    if (std::abs(value) > 0.00001F) {
                        bodyMorph->SetMorph(resolved.get(), name.c_str(),
                            kPreviewKey, -value);
                    }
                }
                ApplyVisibleMorphs(*bodyMorph, resolved.get(), false);
            });
        return ApplyResult::queued;
    }

    void QueueReapplyCurrent(RE::Actor* actor, const bool forceCommit)
    {
        const auto presetId = CurrentPresetId(actor);
        if (!actor || !presetId) return;
        if (forceCommit) {
            // The settings popup is an explicit user action, including while
            // its preview owner is active. Preserve its immediate commit path.
            if (QueueApply(actor, *presetId, ApplyMode::commit) == ApplyResult::queued) {
                bcn::OutfitRefit::Get().ProcessActor(actor);
            }
            return;
        }
        const auto handle = actor->GetHandle();
        const auto session = ActorRegistry::Get().SessionGeneration();
        QueueActorTask(handle, appearance::WorkChannel::bodyVerify, [handle, session, presetId] {
            if (!frame_tasks::CurrentWorkAllowed() ||
                ActorRegistry::Get().SessionGeneration() != session) return;
            const auto resolved = handle.get();
            if (!resolved || !resolved->Is3DLoaded() || !IsReady() ||
                CurrentPresetId(resolved.get()) != presetId ||
                frame_tasks::HasPreview(resolved->GetFormID()) || HasActivePreview(resolved.get()) || IsBodySliderEditing(resolved.get()) ||
                frame_tasks::HasActorChannelWork(resolved->GetFormID(), appearance::WorkChannel::bodyCommit) ||
                frame_tasks::HasActorChannelWork(resolved->GetFormID(), appearance::WorkChannel::bodyPreviewCleanup)) return;
            if (ActorRegistry::Get().NeedsBodyApply(resolved.get(), *presetId, false)) {
                // Missing keys, changed XML or changed options still need a
                // real commit. Explicit UI commits retain their normal recipe.
                if (QueueApply(resolved.get(), *presetId, ApplyMode::commit) != ApplyResult::queued) return;
            } else if (auto* current = Interface()) {
                // Surviving cosave keys are already authoritative. Rebuilding
                // geometry must not reroll or overwrite that committed layer.
                ApplyVisibleMorphs(*current, resolved.get(), false);
            }
            bcn::OutfitRefit::Get().ProcessActor(resolved.get());
        });
    }

    ApplyResult QueueApplyOutfit(RE::Actor* actor, std::string refitPresetId,
        const std::uint64_t outfitSignature)
    {
        return QueueApply(actor, std::move(refitPresetId), ApplyMode::outfit,
            outfitSignature, UpdatePolicy::deferred);
    }

    void QueueCancelPreview()
    {
        const auto actorHandle = CancelPreviewTracking();
        if (!actorHandle) return;
        if (const auto* tasks = SKSE::GetTaskInterface()) {
            const auto session = bcn::ActorRegistry::Get().SessionGeneration();
            // Survive detach while waiting out RaceMenu. Keep actor FIFO and
            // the existing new-preview/session guards instead of anonymous undo.
            QueueActorTask(actorHandle, bcn::appearance::WorkChannel::bodyPreviewCleanup,
                [actorHandle, session] {
                    if (bcn::ActorRegistry::Get().SessionGeneration() == session) ClearPreviewNow(actorHandle);
                });
        }
    }

    void QueueClearInactivePreview(RE::Actor* actor)
    {
        if (!actor || !IsReady()) return;
        const auto handle = actor->GetHandle();
        const auto session = ActorRegistry::Get().SessionGeneration();
        QueueActorTask(handle, appearance::WorkChannel::bodyPreviewCleanup, [handle, session] {
            if (ActorRegistry::Get().SessionGeneration() == session) ClearPreviewNow(handle);
        });
    }

    void QueueApplyProceduralOutfit(RE::Actor* actor, const std::uint64_t outfitSignature)
    {
        if (!IsReady() || !actor) return;
        const auto actorHandle = actor->GetHandle();
        const auto generation = BeginApply(actor->GetFormID(), ApplyMode::outfit);
        if (const auto* tasks = SKSE::GetTaskInterface()) {
            const auto session = bcn::ActorRegistry::Get().SessionGeneration();
            QueueActorTask(actorHandle, bcn::appearance::WorkChannel::outfitRefit,
                [actorHandle, outfitSignature, session, generation] {
                const auto actor = actorHandle.get();
                if (actor && bcn::ActorRegistry::Get().SessionGeneration() == session &&
                    IsCurrentApply(actor->GetFormID(), ApplyMode::outfit, generation)) {
                    if (!bcn::rendered_outfit::ValidateApply(actor.get())) return;
                    ApplyProceduralOutfitNow(actorHandle, outfitSignature);
                }
            });
        }
    }

    void QueueClearOutfit(RE::Actor* actor, const std::uint64_t outfitSignature)
    {
        if (!IsReady() || !actor) return;
        // Clearing a refit must never cancel a body preset that was just
        // queued by the same UI click.  Body, preview and outfit use separate
        // RaceMenu keys and therefore require separate generations as well.
        const auto generation = InvalidateApply(actor->GetFormID(), ApplyMode::outfit);
        const auto actorHandle = actor->GetHandle();
        if (const auto* tasks = SKSE::GetTaskInterface()) {
            const auto session = bcn::ActorRegistry::Get().SessionGeneration();
            QueueActorTask(actorHandle, bcn::appearance::WorkChannel::outfitRefit,
                [actorHandle, outfitSignature, session, generation] {
                if (bcn::ActorRegistry::Get().SessionGeneration() != session) return;
                auto* bodyMorph = Interface();
                const auto resolved = actorHandle.get();
                if (!bodyMorph || !resolved || !resolved->Is3DLoaded()) return;
                if (!IsCurrentApply(resolved->GetFormID(), ApplyMode::outfit, generation)) return;
                if (!bcn::rendered_outfit::ValidateApply(resolved.get())) return;
                const auto hadOutfitMorph =
                    bodyMorph->HasBodyMorphKey(resolved.get(), kOutfitKey) ||
                    bodyMorph->HasBodyMorphKey(resolved.get(), kLegacyOutfitKey);
                bodyMorph->ClearBodyMorphKeys(resolved.get(), kOutfitKey);
                bodyMorph->ClearBodyMorphKeys(resolved.get(), kLegacyOutfitKey);
                // Do not rebuild every body just to clear a key that never
                // existed. This was a full synchronous morph pass even when
                // outfit correction was disabled or the actor was naked.
                if (hadOutfitMorph) ApplyVisibleMorphs(*bodyMorph, resolved.get(), true);
                bcn::ActorRegistry::Get().MarkOutfitApplied(resolved.get(), outfitSignature);
            });
        }
    }

    void CancelPendingOutfit(RE::Actor* actor)
    {
        if (actor) InvalidateApply(actor->GetFormID(), ApplyMode::outfit);
    }

    ApplyResult QueueClearBodyChangeMorphs(RE::Actor* actor, const bool ownedOnly, const BodyClearReason reason)
    {
        if (!IsReady()) return ApplyResult::unavailable;
        if (!actor) return ApplyResult::invalidActor;
        if (!frame_tasks::Active() || !SKSE::GetTaskInterface()) return ApplyResult::noTaskInterface;
        if (reason == BodyClearReason::ordinary && HasPSQTemporaryPreset(actor)) return ApplyResult::psqTemporaryPresetActive;
        if (reason == BodyClearReason::explicitReset && actor->IsPlayerRef()) CancelPSQTemporaryRequest();
        InvalidateActorApplies(actor->GetFormID());
        const auto clearGeneration = BeginApply(actor->GetFormID(), ApplyMode::commit);
        {
            std::scoped_lock lock(g_selectionLock);
            // A pending default must not fall back to an older applied ID.
            g_currentPresetIds[actor->GetFormID()] = {};
        }
        const auto actorHandle = actor->GetHandle();
        if (const auto* tasks = SKSE::GetTaskInterface()) {
            // This clear also removes the outfit key. A later equipment/SFS
            // evaluation must not skip it because of an old success signature.
            bcn::ActorRegistry::Get().InvalidateOutfit(actor);
            const auto session = bcn::ActorRegistry::Get().SessionGeneration();
            const auto previousActor = CancelPreviewTracking(actorHandle);
            if (previousActor && previousActor != actorHandle) {
                QueueActorTask(previousActor,
                    bcn::appearance::WorkChannel::bodyPreviewCleanup, [previousActor, session] {
                    if (bcn::ActorRegistry::Get().SessionGeneration() == session) ClearPreviewNow(previousActor);
                });
            }
            QueueActorTask(actorHandle, bcn::appearance::WorkChannel::bodyCommit,
                [actorHandle, session, clearGeneration, ownedOnly, reason] {
                if (bcn::ActorRegistry::Get().SessionGeneration() != session) return;
                auto* bodyMorph = Interface();
                const auto resolved = actorHandle.get();
                if (!bodyMorph || !resolved) return;
                if (reason == BodyClearReason::ordinary && HasPSQTemporaryPreset(resolved.get())) return;
                if (!IsCurrentApply(resolved->GetFormID(), ApplyMode::commit, clearGeneration)) return;
                FinishBodySliderEdit(resolved.get());
                if (ownedOnly) keys::ClearOwned(*bodyMorph, resolved.get());
                else keys::ClearReplacedBody(*bodyMorph, resolved.get());
                if (resolved->Is3DLoaded()) ApplyVisibleMorphs(*bodyMorph, resolved.get(), false);
                bcn::ActorRegistry::Get().MarkBodyApplied(resolved.get(), {}, true);
            });
            return ApplyResult::queued;
        }
        return ApplyResult::noTaskInterface;
    }

    bool QueueClearAllBodyChangeMorphs(std::vector<std::uint32_t> alreadyReset, const bool ownedOnly)
    {
        if (!bcn::frame_tasks::Active() || !IsReady()) return false;
        const auto* tasks = SKSE::GetTaskInterface();
        if (!tasks) return false;
        CancelPSQTemporaryRequest();
        {
            std::scoped_lock lock(g_selectionLock);
            g_currentPresetIds.clear();
        }
        [[maybe_unused]] const auto previousActor = CancelPreviewTracking();
        const auto session = bcn::ActorRegistry::Get().SessionGeneration();
        const auto resetCutoff = g_nextApplyGeneration.load(std::memory_order_relaxed);
        std::ranges::sort(alreadyReset);
        return bcn::frame_tasks::Queue(0, [session, resetCutoff, ownedOnly, alreadyReset = std::move(alreadyReset)] {
            if (bcn::ActorRegistry::Get().SessionGeneration() != session) return;
            auto* bodyMorph = Interface();
            if (!bodyMorph) return;
            MorphActorCollector collector;
            bodyMorph->VisitActors(collector);
            std::ranges::sort(collector.actorFormIDs);
            collector.actorFormIDs.erase(
                std::unique(collector.actorFormIDs.begin(), collector.actorFormIDs.end()),
                collector.actorFormIDs.end());
            std::size_t cleared{};
            for (const auto formID : collector.actorFormIDs) {
                if (std::ranges::binary_search(alreadyReset, formID) ||
                    CurrentApplyGeneration(formID, ApplyMode::commit) >= resetCutoff ||
                    CurrentApplyGeneration(formID, ApplyMode::preview) >= resetCutoff) continue;
                auto* actor = RE::TESForm::LookupByID<RE::Actor>(formID);
                if (!actor) continue;
                const auto owned = bodyMorph->HasBodyMorphKey(actor, kPreviewKey) ||
                    bodyMorph->HasBodyMorphKey(actor, kCommittedKey) ||
                    bodyMorph->HasBodyMorphKey(actor, kOutfitKey) ||
                    bodyMorph->HasBodyMorphKey(actor, kLegacyPreviewKey) ||
                    bodyMorph->HasBodyMorphKey(actor, kLegacyCommittedKey) ||
                    bodyMorph->HasBodyMorphKey(actor, kLegacyOutfitKey) ||
                    bodyMorph->HasBodyMorphKey(actor, keys::editorBaseline) ||
                    bodyMorph->HasBodyMorphKey(actor, keys::editorOffset) ||
                    bodyMorph->HasBodyMorphKey(actor, temporary_body::key);
                if (!owned) continue;
                InvalidateActorApplies(formID);
                const auto generation = BeginApply(formID, ApplyMode::commit);
                const auto handle = actor->GetHandle();
                QueueActorTask(handle, bcn::appearance::WorkChannel::bodyCommit,
                    [handle, generation, ownedOnly] {
                    const auto resolved = handle.get();
                    auto* morph = Interface();
                    if (!resolved || !morph || !IsCurrentApply(resolved->GetFormID(), ApplyMode::commit, generation)) return;
                    // Keep the BCNG-actor eligibility above; remove competing
                    // OBody layers on these actors just like individual reset.
                    FinishBodySliderEdit(resolved.get());
                    if (ownedOnly) keys::ClearOwned(*morph, resolved.get());
                    else keys::ClearReplacedBody(*morph, resolved.get());
                    if (resolved->Is3DLoaded()) ApplyVisibleMorphs(*morph, resolved.get(), false);
                });
                ++cleared;
            }
            SKSE::log::info("Body Change NG queued owned body morph reset for {} saved actors", cleared);
        });
    }

    std::optional<std::size_t> RemainingOwnedMorphActors()
    {
        auto* morph = Interface();
        if (!morph || !IsReady()) return std::nullopt;
        MorphActorCollector collector;
        morph->VisitActors(collector);
        std::size_t remaining{};
        for (const auto id : collector.actorFormIDs) {
            auto* actor = RE::TESForm::LookupByID<RE::Actor>(id);
            if (!actor) { ++remaining; continue; }
            if (std::ranges::any_of(keys::owned, [&](const auto* key) {
                    return morph->HasBodyMorphKey(actor, key);
                })) ++remaining;
        }
        return remaining;
    }
}
