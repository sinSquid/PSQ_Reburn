#pragma once
#include <cstdint>
namespace bcn::psq_equipment_refresh
{
    struct Ticket {
        std::int32_t id{};
        std::uint64_t epoch{}, session{};
        bool operator==(const Ticket&) const = default;
    };
    [[nodiscard]] constexpr bool CanAcknowledge(const Ticket& captured, const Ticket& current,
        const std::uint64_t epoch, const std::uint64_t session) noexcept
    {
        return captured.id > 0 && captured == current &&
            captured.epoch == epoch && captured.session == session;
    }
}
