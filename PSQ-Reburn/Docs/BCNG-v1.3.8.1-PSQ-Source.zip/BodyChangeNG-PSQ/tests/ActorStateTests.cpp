#include "BodyChangeNG/ActorState.h"
#include "BodyChangeNG/ActorRecordBatches.h"
#include "BodyChangeNG/ActorSearchPolicy.h"
#include "BodyChangeNG/ActorWorkQueue.h"
#include "BodyChangeNG/Distribution.h"
#include "BodyChangeNG/DistributionRuleNames.h"
#include "BodyChangeNG/RaceMenuBodyMorph.h"
#include "BodyChangeNG/Settings.h"

#include <cmath>
#include <iostream>
#include <stdexcept>

namespace
{
    void Require(const bool value, const char* message)
    {
        if (!value) throw std::runtime_error(message);
    }

    void CheckRecordBatches()
    {
        namespace codec = bcn::actor_serialization;
        for (const std::size_t count : {0U, 1U, 16383U, 16384U, 16385U, 33000U}) {
            std::vector<bcn::ActorState> states(count);
            for (std::size_t i{}; i < count; ++i) {
                states[i].actorFormID = static_cast<std::uint32_t>(i + 1U);
                states[i].body.selection = { .selectedId = "body-" + std::to_string(i), .manual = true };
                if (i % 3U == 0U) bcn::ResetActorSelectionsToDefaults(states[i]);
            }
            std::size_t restored{}, records{};
            Require(codec::WriteActorRecords(states, [&](const auto& strings, const auto& actors) {
                ++records;
                Require(strings.size() <= codec::kMaxRecordStrings && actors.size() <= codec::kMaxRecordActors,
                    "record exceeded legacy loader limits");
                for (const auto& actor : actors) {
                    const auto decoded = codec::DecodeV6(actor.state, actor.overlays, strings);
                    Require(decoded && decoded->actorFormID == states[restored].actorFormID &&
                        decoded->body.selection.selectedId == states[restored].body.selection.selectedId &&
                        decoded->body.selection.useDefault == states[restored].body.selection.useDefault &&
                        decoded->body.selection.manual, "record split lost an actor/default/manual selection");
                    ++restored;
                }
                return true;
            }), "actor record write failed");
            Require(restored == count && records == (std::max)(std::size_t{1}, (count + 16383U) / 16384U),
                "actor cap silently truncated state");
        }
        // Hit the independent string-table bound well before the actor bound.
        std::vector<bcn::ActorState> dense(600U);
        for (std::size_t i{}; i < dense.size(); ++i) {
            dense[i].actorFormID = static_cast<std::uint32_t>(i + 1U);
            for (unsigned slot{}; slot < 64U; ++slot) {
                const auto id = std::to_string(i) + "-" + std::to_string(slot);
                for (unsigned area{}; area < 2U; ++area)
                    dense[i].overlay.areas[area].items.push_back({id + "-" + std::to_string(area),
                        id + "-" + std::to_string(area) + ".dds", static_cast<std::uint8_t>(slot), 0x12345678U});
            }
        }
        std::size_t restored{}, records{};
        Require(codec::WriteActorRecords(dense, [&](const auto& strings, const auto& actors) {
            ++records;
            Require(strings.size() <= codec::kMaxRecordStrings, "string-table cap exceeded");
            for (const auto& actor : actors) {
                const auto decoded = codec::DecodeV6(actor.state, actor.overlays, strings);
                Require(decoded && decoded->overlay.areas[1].items.size() == 64U &&
                    decoded->overlay.areas[1].items.back().color == 0x12345678U, "overlay batch lost ownership/color");
                ++restored;
            }
            return true;
        }) && restored == dense.size() && records > 1U, "string-boundary save lost records");
        records = 0U;
        Require(!codec::WriteActorRecords(dense, [&](const auto&, const auto&) { ++records; return false; }) &&
            records == 1U, "failed record write did not stop");
        bcn::ActorState empty;
        empty.body.outfitSignature = 17U;
        Require(!bcn::HasPersistentAppearance(empty), "transient refit cache became a saved appearance");
        auto selected = empty;
        selected.skin.selection.useDefault = true;
        Require(bcn::HasPersistentAppearance(selected), "Default intent discarded");
        selected = empty;
        selected.overlay.areas[0].items.push_back({.ownedSlot = 3U});
        Require(bcn::HasPersistentAppearance(selected), "pending owned overlay discarded");
        selected = empty;
        selected.futanari.manual = true;
        Require(bcn::HasPersistentAppearance(selected), "manual futanari lock discarded");
    }
}

int main()
{
    {
        bcn::ActorState state;
        state.body.selection = { .selectedId = "body", .manual = false };
        state.body.application = { .appliedId = "body", .applied = true };
        state.body.outfitSignature = 42U;
        state.skin.selection = { .selectedId = "skin", .manual = false };
        state.futanari = { .selectedSkinId = "futa", .manual = false };
        for (auto& area : state.overlay.areas) {
            area.items.push_back({ .selectedId = "overlay", .texturePath = "overlay.dds" });
        }
        bcn::ResetActorSelectionsToDefaults(state);
        Require(state.body.selection.manual && state.body.selection.useDefault &&
            state.body.selection.selectedId.empty() && !state.body.application.applied &&
            state.body.outfitSignature == 0U,
            "actor settings reset did not clear the body channel");
        Require(state.skin.selection.manual && state.skin.selection.useDefault &&
            state.skin.selection.selectedId.empty() && !state.skin.application.applied,
            "actor settings reset did not clear the skin channel");
        Require(state.futanari.manual && state.futanari.useDefault &&
            state.futanari.selectedSkinId.empty(),
            "actor settings reset did not clear the futanari channel");
        Require(std::ranges::all_of(state.overlay.areas, [](const auto& area) {
            return area.manual && area.useDefault && area.items.size() == 1U && area.resetRevision == 1U;
        }), "reset discarded native ownership before removal");
    }
    try {
        CheckRecordBatches();
        using bcn::actor_search::Matches;
        using bcn::actor_search::Normalize;
        Require(Normalize("  BaNdIt\t") == "bandit", "search normalization failed");
        Require(Matches("bandit", "Bandit Marauder", 0xAB123456U), "name search failed");
        Require(Matches("산적", "산적 두목", 0xAB123456U), "UTF-8 name search failed");
        Require(Matches("bandit", "Bandit", 0x100U) && Matches("bandit", "Bandit", 0x200U),
            "same-named references must not be deduplicated by name");
        Require(Matches(Normalize("0XAB123456"), "NPC", 0xAB123456U) &&
            Matches("123456", "NPC", 0xAB123456U), "hex RefID search failed");
        Require(!Matches("", "NPC", 0xAB123456U) && !Matches("0x", "NPC", 0xAB123456U) &&
            !Matches("0x12345678", "NPC", 0xAB123456U), "empty/unmatched search accepted");
        for (const auto mode : { bcn::overlay::ApplyMode::preview,
                bcn::overlay::ApplyMode::manualCommit, bcn::overlay::ApplyMode::automatic,
                bcn::overlay::ApplyMode::restore }) {
            bcn::ActorState state;
            auto& area = state.overlay.areas[0];
            area.items.push_back({ "old", "old.dds", 2U });
            const auto started = area.resetRevision;
            bcn::ResetActorSelectionsToDefaults(state);
            Require(!bcn::CompleteOverlayTransaction(area, { "late", "late.dds", 2U }, mode, started),
                "a pre-reset completion resurrected its selection");
            Require(area.manual && area.useDefault && area.items.size() == 1U &&
                    area.items.front().texturePath == "late.dds",
                "late completion lost its exact cleanup ownership");
            area.items.clear(); // native exact-node removal completed
            Require(bcn::CompleteOverlayTransaction(area, { "new", "new.dds", 2U, 0x12345678U },
                bcn::overlay::ApplyMode::manualCommit, area.resetRevision) &&
                !area.useDefault && area.items.size() == 1U && area.items.front().color == 0x12345678U,
                "a new selection after reset was incorrectly blocked");
        }
        // Schema 4 appends new scopes. Existing schema-3 numeric values must
        // never move, or a saved rule could silently change meaning.
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::allNPCs) == 0U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::npcBaseForm) == 1U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::npcName) == 2U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::factionEditorID) == 3U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::pluginFile) == 4U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::raceEditorID) == 5U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::modInstalledFollower) == 6U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::elderNPC) == 7U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::keyword) == 8U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::npcClass) == 9U);
        static_assert(static_cast<std::uint8_t>(bcn::DistributionScope::combatStyle) == 10U);
        for (unsigned scope = 0; scope <= 10U; ++scope) {
            for (unsigned options = 0; options < 8U; ++options) {
                for (unsigned traits = 0; traits < 8U; ++traits) {
                    bcn::DistributionRule filter;
                    filter.scope = static_cast<bcn::DistributionScope>(scope);
                    filter.includeCustomFollowers = (options & 1U) != 0U;
                    filter.includeElderNPCs = (options & 2U) != 0U;
                    filter.includeChildNPCs = (options & 4U) != 0U;
                    const auto follower = (traits & 1U) != 0U;
                    const auto elder = (traits & 2U) != 0U;
                    const auto child = (traits & 4U) != 0U;
                    const auto expected = scope != 0U ||
                        ((!follower || filter.includeCustomFollowers) &&
                            (!elder || filter.includeElderNPCs) &&
                            (!child || filter.includeChildNPCs));
                    Require(bcn::MatchesDistributionScopeFilters(filter, follower, elder, child) == expected,
                        "All-NPC exclusion leaked into an explicit target or ignored its checkbox");
                }
            }
        }
        using bcn::StableStateSignature;
        const auto body = StableStateSignature("body", "preset-a", false, 0U);
        Require(body == StableStateSignature("body", "preset-a", false, 0U),
            "identical body state was not stable");
        Require(body != StableStateSignature("body", "preset-b", false, 0U),
            "different preset IDs collided");
        Require(body != StableStateSignature("skin", "preset-a", false, 0U),
            "channel identity was not included");
        Require(body != StableStateSignature("body", "preset-a", true, 0U),
            "default and selected state collided");
        Require(body != StableStateSignature("body", "preset-a", false, 1U),
            "randomization options were not included");
        Require(body != StableStateSignature("body", "PRESET-A", false, 0U),
            "asset normalization changed existing body signatures");
        const auto skin = StableStateSignature("skin", "BoDySkIn/Pack", false, 0U, 42U, true);
        Require(skin == StableStateSignature("skin", "bodyskin\\pack", false, 0U, 42U, true),
            "case-only saved skin ID would trigger repeated application");
        Require(skin != StableStateSignature("skin", "bodyskin/other", false, 0U, 42U, true) &&
                skin != StableStateSignature("skin", "bodyskin/pack", false, 0U, 43U, true),
            "skin identity normalization lost pack or content changes");
        Require(bcn::UsesQueuedAutomaticPath(false) && bcn::UsesQueuedAutomaticPath(true),
            "an automatic actor mode bypassed the coalescing queue");
        Require(bcn::AutomaticActorBudget(false) == 4U,
            "normal mode actor budget changed");
        Require(bcn::AutomaticActorBudget(true) == 2U,
            "performance mode actor budget changed");
        Require(bcn::InitialDistributionDelayTicks() == 2U,
            "initial distribution no longer yields to save-load listeners");
        Require(bcn::DistributionReferenceSeed(bcn::DistributionFeature::skin, 0x1234U) == 0U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::body, 0x1234U) == 0x1234U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::futanari, 0x1234U) == 0x1234U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::overlayFace, 0x1234U) == 0x1234U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::overlayBody, 0x1234U) == 0x1234U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::overlayHands, 0x1234U) == 0x1234U &&
                bcn::DistributionReferenceSeed(bcn::DistributionFeature::overlayFeet, 0x1234U) == 0x1234U,
            "native skin distribution escaped ActorBase scope or body distribution lost reference scope");
        Require(!bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::skin) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::body) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::futanari) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::overlayFace) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::overlayBody) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::overlayHands) &&
                bcn::MayRetainPreviousDistributionSelection(bcn::DistributionFeature::overlayFeet),
            "a legacy reference-scoped skin choice could prevent ActorBase convergence");
        Require(bcn::IsDistributionActorStateEligible(false, false, false, true, true) &&
                bcn::IsDistributionActorStateEligible(false, false, true, true, true),
            "loaded corpses were excluded from NPC distribution");
        Require(!bcn::IsDistributionActorStateEligible(true, false, false, true, true) &&
                !bcn::IsDistributionActorStateEligible(false, true, false, true, true) &&
                !bcn::IsDistributionActorStateEligible(false, false, false, false, true) &&
                !bcn::IsDistributionActorStateEligible(false, false, false, true, false),
            "NPC distribution eligibility lost a player/disabled/3D/type safety boundary");
        Require(StableStateSignature("body", "same", false, 0, 1ULL) !=
            StableStateSignature("body", "same", false, 0, 0x100000001ULL), "upper content hash bits lost");
        const auto omittedCorrection = bcn::racemenu::PreviewPresetCorrection(0.0F, 0.4F);
        Require(std::abs(omittedCorrection + 0.4F) < 0.00001F &&
                std::abs(0.4F + omittedCorrection) < 0.00001F,
            "an XML-omitted owned body slider was not cancelled by preview");
        const auto firstCorrection = bcn::racemenu::PreviewPresetCorrection(0.8F, 0.35F);
        const auto repeatedCorrection = bcn::racemenu::PreviewPresetCorrection(0.8F, 0.35F);
        Require(firstCorrection == repeatedCorrection &&
                std::abs(0.35F + repeatedCorrection - 0.8F) < 0.00001F,
            "repeated preview accumulated body morph values");
        const auto previewCorrection = bcn::racemenu::PreviewPresetCorrection(0.8F, 0.95F);
        Require(std::abs(1.05F + previewCorrection - 0.9F) < 0.00001F,
            "preview normalization did not preserve the current outfit correction");
        const auto externalMorph = 0.35F;
        const auto committedMorph = 0.8F;
        const auto outfitCorrection = bcn::racemenu::OutfitTargetCorrection(
            0.0F, committedMorph);
        Require(std::abs(externalMorph + committedMorph + outfitCorrection - externalMorph) < 0.00001F,
            "procedural outfit correction counteracted an external RaceMenu morph contribution");

        bcn::ActorState state{
            .actorFormID = 0x1234U,
            .baseLocalFormID = 0x5678U,
            .basePlugin = "Example.esp",
            .body = {
                .selection = { .selectedId = "preset-a", .manual = true },
                .application = { .signature = body }
            },
            .skin = {
                .selection = { .selectedId = "skin-a", .manual = true },
                .application = { .signature = StableStateSignature("skin", "skin-a", false) }
            },
            .overlay = { .areas = {
                bcn::OverlayAreaState{ .items = { { "face-a", "textures\\paint\\face-a.dds", 1U } }, .manual = true },
                bcn::OverlayAreaState{ .items = { { "body-a", "textures\\paint\\body-a.dds", 2U } } },
                bcn::OverlayAreaState{},
                bcn::OverlayAreaState{}
            } },
            .futanari = { .selectedSkinId = "futanari:skin-a:cbbe-trx", .manual = true }
        };
        Require(state.body.selection.manual && state.skin.selection.manual &&
                state.body.selection.selectedId != state.skin.selection.selectedId,
            "body and skin channels did not remain independent");
        bcn::FeatureSelectionState automatic{ .selectedId = "saved-skin" };
        bcn::UpdateAutomaticSelection(automatic, std::nullopt);
        Require(automatic.selectedId == "saved-skin" && !automatic.useDefault,
            "an unchanged automatic rule erased its serialized selection");
        bcn::UpdateAutomaticSelection(automatic, std::string{ "new-skin" });
        Require(automatic.selectedId == "new-skin" && !automatic.useDefault,
            "an automatic rule did not store its selected asset");
        bcn::UpdateAutomaticSelection(automatic, std::nullopt, true);
        Require(automatic.selectedId.empty() && automatic.useDefault,
            "an automatic Default decision was collapsed into unchanged state");
        bcn::FeatureSelectionState manualSelection{
            .selectedId = "manual-skin", .manual = true };
        bcn::UpdateAutomaticSelection(manualSelection, std::string{ "rule-skin" });
        Require(manualSelection.selectedId == "manual-skin" && manualSelection.manual,
            "automatic distribution overwrote a direct actor selection");
        state.body.application.applied = state.skin.application.applied = true;
        state.body.application.verifiedThisSession = state.skin.application.verifiedThisSession = true;
        bcn::PrepareRestoredState(state);
        Require(state.body.application.applied && state.skin.application.applied &&
                state.futanari.selectedSkinId == "futanari:skin-a:cbbe-trx" &&
                !state.body.application.verifiedThisSession &&
                !state.skin.application.verifiedThisSession,
            "cosave restore lost the futanari selection or live-session proof boundary");
        const auto preservedBodyBeforeReset = state.body;
        const auto preservedSkin = state.skin;
        const auto preservedOverlay = state.overlay;
        const auto preservedFutanari = state.futanari;
        state.body = {};
        Require(state.skin.selection.selectedId == preservedSkin.selection.selectedId &&
                state.skin.application.signature == preservedSkin.application.signature &&
                state.overlay.areas[0].items.front().selectedId == preservedOverlay.areas[0].items.front().selectedId &&
                state.futanari.selectedSkinId == preservedFutanari.selectedSkinId,
            "resetting body state crossed the skin, overlay, or futanari feature boundary");
        state.body = preservedBodyBeforeReset;
        const auto preservedBody = state.body;
        state.skin = {};
        Require(state.body.selection.selectedId == preservedBody.selection.selectedId &&
                state.body.application.signature == preservedBody.application.signature &&
                state.overlay.areas[1].items.front().selectedId == preservedOverlay.areas[1].items.front().selectedId &&
                state.futanari.selectedSkinId == preservedFutanari.selectedSkinId,
            "resetting skin state crossed the body, overlay, or futanari feature boundary");
        using Decision = bcn::RestoredApplicationDecision;
        Require(bcn::EvaluateRestoredApplication(true, false, true, true) == Decision::acceptLive,
            "a matching restored live state was not accepted");
        Require(bcn::EvaluateRestoredApplication(true, false, true, false) == Decision::apply &&
                bcn::EvaluateRestoredApplication(true, false, true, std::nullopt) == Decision::apply,
            "a missing or unverifiable restored live state was incorrectly skipped");
        Require(bcn::EvaluateRestoredApplication(true, true, true, std::nullopt) == Decision::skipVerified,
            "current-session verification was not cached");
        Require(bcn::EvaluateRestoredApplication(true, false, false, true) == Decision::apply,
            "a stale persisted signature was accepted from live state alone");
        // A success earlier in this same session cannot hide lost live keys.
        for (const bool verified : {false, true}) {
            bcn::FeatureApplicationState application;
            application.applied = true;
            application.verifiedThisSession = verified;
            Require(bcn::EvaluateLiveBodyApplication(application, true, false) == Decision::apply,
                "a previously verified NPC with missing morphs skipped recovery");
            Require(bcn::EvaluateLiveBodyApplication(application, true, true) == Decision::acceptLive,
                "an intact NPC body unnecessarily scheduled another rebuild");
            Require(bcn::EvaluateLiveBodyApplication(application, false, true) == Decision::apply,
                "a changed preset signature retained stale body morphs");
            Require(bcn::EvaluateLiveBodyApplication(application, true, std::nullopt) == Decision::apply,
                "an unavailable backend was mistaken for verified live morphs");
        }
        bcn::DistributionRule rule{
            .female = true,
            .bodyFamily = "CBBE 3BA",
            .presetIds = { "female-body" },
            .skinProfileIds = { "female-skin" },
            .futanariSkinIds = { "female-futanari" },
            .overlayIds = { std::vector<std::string>{ "face-paint" },
                std::vector<std::string>{ "body-paint" }, {}, {} }
        };
        Require(!rule.includeCustomFollowers && !rule.includeElderNPCs && !rule.includeChildNPCs,
            "positive all-NPC rules did not exclude optional NPC groups by default");
        rule.overlayColors[0]["face-paint"] = 0x008000FFU;
        rule.overlayColors[1]["body-paint"] = 0xFF123456U;
        rule.overlayColors[0]["removed-paint"] = 0xFFFFFFFFU;
        bcn::PruneDistributionOverlayColors(rule);
        Require(rule.overlayColors[0].size() == 1U &&
                bcn::DistributionOverlayColor(rule, bcn::overlay::Area::face, "face-paint") == 0x008000FFU &&
                bcn::DistributionOverlayColor(rule, bcn::overlay::Area::body, "body-paint") == 0xFF123456U &&
                bcn::DistributionOverlayColor(rule, bcn::overlay::Area::hands, "absent") == 0xFFFFFFFFU,
            "per-candidate colors lost alpha, crossed areas, or retained deleted IDs");
        Require(bcn::SetDistributionRuleSex(rule, false), "rule sex change was not detected");
        Require(!rule.female && rule.bodyFamily.empty() && rule.presetIds.empty() &&
                rule.skinProfileIds.empty() && rule.futanariSkinIds.empty() &&
                rule.overlayIds[0].empty() &&
                rule.overlayIds[1].empty() && rule.overlayColors[0].empty() && rule.overlayColors[1].empty(),
            "rule sex change retained a hidden opposite-sex catalog selection");
        rule.presetIds = { "male-body" };
        Require(!bcn::SetDistributionRuleSex(rule, false) && rule.presetIds.size() == 1U,
            "unchanged rule sex unnecessarily destroyed compatible selections");
        Require(bcn::NpcDistributionFamily(bcn::FemaleNpcBodyType::cbbe3ba) ==
                bcn::body_family::Bit(bcn::body_family::Family::cbbe) &&
                bcn::NpcDistributionFamily(bcn::FemaleNpcBodyType::bhunpUnp) ==
                bcn::body_family::Bit(bcn::body_family::Family::unp) &&
                bcn::NpcDistributionFamily(bcn::FemaleNpcBodyType::ube) ==
                bcn::body_family::Bit(bcn::body_family::Family::ube) &&
                bcn::NpcDistributionFamily(bcn::MaleNpcBodyType::himbo) ==
                bcn::body_family::Bit(bcn::body_family::Family::himbo) &&
                bcn::NpcDistributionFamily(bcn::MaleNpcBodyType::sam) ==
                bcn::body_family::Bit(bcn::body_family::Family::sam),
            "NPC distribution body-type settings crossed family boundaries");
        Require(!bcn::UsesNpcBodyPreset(bcn::FemaleNpcBodyType::vanilla) &&
                !bcn::UsesNpcBodyPreset(bcn::MaleNpcBodyType::vanilla) &&
                bcn::UsesNpcBodyPreset(bcn::FemaleNpcBodyType::cbbe3ba) &&
                bcn::UsesNpcBodyPreset(bcn::MaleNpcBodyType::himbo),
            "Vanilla NPC body settings did not disable only automatic BodySlide morph distribution");
        const bcn::SettingsData defaultSettings;
        Require(defaultSettings.femaleNpcBodyType == bcn::FemaleNpcBodyType::cbbe3ba &&
                defaultSettings.maleNpcBodyType == bcn::MaleNpcBodyType::himbo,
            "new-install NPC body-type defaults were not CBBE 3BA and HIMBO");
        namespace names = bcn::distribution_names;
        for (const auto& entry : names::kEntries) {
            Require(!names::Localized(entry.key, bcn::UiLanguage::korean).empty() &&
                    !names::Localized(entry.key, bcn::UiLanguage::english).empty() &&
                    !names::Localized(entry.key, bcn::UiLanguage::chineseSimplified).empty(),
                "a distribution-rule name is missing a Korean, English, or Chinese translation");
            Require(names::IsLocalizedValue(entry.key, entry.korean) &&
                    names::IsLocalizedValue(entry.key, entry.english) &&
                    names::IsLocalizedValue(entry.key, entry.chinese),
                "a localized distribution-rule name could not be recognized after loading");
        }
        Require(names::RecognizeKey("user-rule-1", "새 여성 NPC 규칙", true) ==
                "rule-new-female" &&
                names::RecognizeKey("rule-11", "새 남성 NPC 규칙", true) ==
                "rule-new-female" &&
                names::RecognizeKey("rule-12", "所有女性 NPC", false) ==
                "rule-all-male",
            "legacy sample/generated rule names did not migrate to language-neutral keys");
        std::vector<bcn::DistributionRule> editableSamples{
            { .id = "rule-all-female", .name = "renamed sample" },
            { .id = "user-rule-1", .name = "user rule" }
        };
        editableSamples.front().scope = bcn::DistributionScope::allNPCs;
        Require(editableSamples.front().name == "renamed sample" &&
                editableSamples.front().scope == bcn::DistributionScope::allNPCs,
            "a built-in sample rule was not editable");
        std::size_t selectedSample{};
        Require(bcn::MoveDistributionRule(editableSamples, selectedSample, 1) &&
                selectedSample == 1U && editableSamples[1].id == "rule-all-female",
            "a built-in sample rule could not be reordered");
        Require(bcn::EraseDistributionRule(editableSamples, selectedSample) &&
                editableSamples.size() == 1U && selectedSample == 0U,
            "a built-in sample rule could not be deleted");
        editableSamples.push_back({ .id = "user-rule-1", .female = true });
        std::uint32_t nextRuleId{ 1U };
        Require(bcn::GenerateUniqueUserRuleId(editableSamples, nextRuleId) == "user-rule-2" &&
                nextRuleId == 3U,
            "a newly created distribution rule reused an existing ImGui/persistent ID");
        std::cout << "ActorStateTests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "ActorStateTests failed: " << error.what() << '\n';
        return 1;
    }
}
