# **BODY CHANGE NG · v1.1.2**
### Change BodySlide presets, actor skins, and player tint masks in real time

**NATIVE IN-GAME GUI  •  GAMEPAD SUPPORT  •  LIVE NPC DISTRIBUTION**

---

## **OVERVIEW**

Body Change NG manages BodySlide body morphs, actor skin textures, and player RaceMenu tint layers from one native in-game interface. Select the player or a loaded NPC, preview changes immediately, edit NPC distribution conditions in game, and either distribute to loaded NPCs now or save the rules for the next launch.

**No MCM. No manual distribution-JSON editing. No runtime body-mesh replacement.**

---

## **WHAT'S NEW IN 1.1.2**

- **Black and gray interface** — window, panel, card, input, and idle-control surfaces now use a consistent black/charcoal/grayscale foundation, while existing selection, hover, warning, success, progress, favorite, and tint-preview colors remain visible as functional highlights
- **Shorter actor refresh label** — the button now reads **Refresh actors**, with matching Korean and Simplified Chinese labels; its loaded-actor refresh behavior is unchanged
- **Reliable saved NPC results** — after loading, BCNG verifies each saved body or skin once and reapplies only a missing or broken result
- **Non-stacking BodyMorph application** — repeated preview and distribution reach the preset's absolute target without deleting morph keys owned by other mods
- **Complete multipart skin routing** — body, hands, feet, face, genital, and conditional race/elder parts keep their correct channels through equipment rebuilds and partial packs
- **Clothed and naked skin consistency** — durable one-slot RaceMenu keys keep body, hands, and feet separate even when an UBE naked limb is absent from the ordinary Biped target list; exact outfit skin nodes are updated as a complementary route
- **Correct UBE and conventional limb atlases** — UBE body, hand, and foot surfaces use the UBE Body atlas; CBBE 3BA/BHUNP hands use their hand atlas while feet use the body atlas unless the pack supplies a dedicated feet set
- **Actor-aware futanari skins** — a conditional catalog supports the active UBE SOS/TNG, CBBE 3BA TRX, or CBBE 3BA ERF genital type, including optional wet companion textures
- **Expanded compatibility** — actor-matched CBBE 3BA and UBE 2.0, standard female/male and SOS skins, Argonian/Khajiit, Racial Skin Variance, Mu Dynamic NormalMap, and improved OverlayFix coexistence
- **More responsive processing** — direct selections are prioritized, required skin files are prepared off the game thread, stale work is cancelled, and automatic distribution remains frame-budgeted
- **Faster MO2 skin catalogs** — one backing DDS exposed through physical and virtual Data paths is hashed only once; full DDS reads do not run per NPC event
- **Safer mixed-body anatomy options** — clothed breast/nipple correction and stable NPC nipple/genital randomization are limited to verified CBBE 3BA actors; UBE actors are skipped with clear in-game guidance

---

## **WHY BODY CHANGE NG?**

### **Compared with OBody NG**

Both mods ultimately deform a built body through RaceMenu BodyMorph and TRI data. Body Change NG does not swap in a separate body mesh. The difference is the selection, distribution, and state-management layer built above that shared morph pipeline.

- **Native GUI instead of an MCM** — press F7 to manage loaded actors, bodies, skins, player tint, and distribution rules in one scalable window
- **Actor-matched Body and Skin lists** — mixed CBBE 3BA and UBE installations are detected per actor from the live winning skin/head path. Skin packs additionally match the actor's humanoid, Argonian, or Khajiit race and female/male sex, so incompatible assets are not mixed; uncertain body-family evidence keeps the safe fallback visible
- **Explicit rule pools** — choose exactly which body presets and skin packs each rule may distribute instead of treating every installed preset as a candidate
- **Independent Body and Skin decisions** — distribute or exclude either category while the other category continues to use its selected pool
- **Visible top-down priority** — the first matching rule owns both decisions, making broad-to-specific ordering easy to inspect and edit
- **Apply now or next launch** — reevaluate loaded NPCs immediately, or save edits for the next launch without changing the active rules in the current session
- **Save-specific results** — selected results and application signatures are stored in the SKSE co-save so unchanged actors do not require full redistribution on every load
- **Isolated live preview** — preview, committed body, and outfit correction use separate owned morph keys; an older queued preview cannot overwrite the latest selection
- **One integrated workflow** — actor skins, player tint detail, RaceMenu rebuild recovery, favorites, and NPC distribution share the same UI and state model

### **Compared with Legacy Mesh-Slot Systems**

Legacy mesh-slot systems build a separate body mesh for each predefined slot, then use Papyrus to replace prepared ESP Skin Armor, HeadPart, and TextureSet records as a unit. A skin slot therefore also requires its matching built mesh and records.

Body Change NG instead uses a native SKSE architecture without predefined ESP body slots.

- **Skin is independent of mesh sets** — the actor keeps its existing Skin Armor, HeadPart, and NIFs while supported texture channels are changed on the loaded body, hands, feet, and face through RaceMenu/NiOverride
- **Body and Skin are freely composable** — body shape is a BodyMorph preset and skin is a separate texture override; either can change without forcing a matching copy of the other
- **No fixed CustomSet1-CustomSet20 slots** — catalogs are built from installed BodySlide XML files and skin/tint folders
- **Runtime installation and refresh** — add BodySlide XML or skin/tint folders while Skyrim is running, press Refresh on that tab, and use them without rebuilding an ESP slot or restarting the game
- **Player and NPC support** — direct selection, conditional NPC Body/Skin distribution, and save-specific evaluated results share one implementation
- **Direct tint editing** — choose player tint assets, edit each layer's color and opacity immediately, or restore its captured RaceMenu value

---

## **FEATURES**

### **Body**

- Select the player or a loaded NPC and apply compatible BodySlide presets immediately
- Low/high-weight values are interpolated using the actor's current weight
- Conservative BodyFamily detection filters the main list while retaining safe fallbacks for uncertain and multi-family presets
- NPC body and skin rule pools use the female/male NPC body family selected in Mod Settings; runtime distribution enforces the same family before choosing a candidate
- Repeated preview, confirmation, and NPC distribution target the selected preset's absolute compatible-family shape; omitted XML sliders target zero through BCNG-owned compensation, not a global morph clear
- CBBE 3BA and UBE use the same SliderPresets folder; Preset set and Group metadata inside each XML identify its family
- Body application uses RaceMenu BodyMorph; no body mesh is generated or replaced while the game is running

### **Skin**

- Apply independent skin packs to the player or a selected loaded NPC
- Persistent RaceMenu/NiOverride keys support body, hands, feet, face, vampire face, diffuse, normal, subsurface, specular, and compatible detail textures
- Body, hands, and feet use separate single-bit skin-slot keys, while exact outfit ArmorAddon nodes are also updated when clothing embeds visible skin; the two routes prevent clothed and naked parts from falling back independently
- Partial skin packs are supported: only supplied parts and channels change, missing values retain the actor's underlying textures, and files are never substituted across body, hands, feet, or face
- Selected skin parts are verified and repaired after equipment or 3D rebuilds, including looting a dead NPC; missing BCNG cache files are rebuilt from the original pack
- Default Skin clears every BCNG-owned body, hand, foot, face, and conditional texture route. A previously managed Default selection is checked only when that actor's equipment changes, so a stale legacy outfit key is removed without scanning unrelated NPCs
- UBE 2.0 Body/Head d-n-sk atlases are detected separately; the Body atlas follows exact UBE body, hand, and foot skin nodes across slots 32/53 while the Head atlas targets the face
- Conventional CBBE 3BA/BHUNP hands use femalehands channels and feet use the body atlas unless an explicit feet atlas exists; exact limb-node matching avoids repainting gloves, boots, or fabric nodes
- The Body Skins tab shows only the selected actor's detected body family; NPC rule pools use the female/male NPC body type selected in Mod Settings
- Argonian and Khajiit female/male folders are detected separately and matched to each actor's race and sex for preview, reapply, and NPC distribution; their body atlas is also applied to the matching live tail geometry
- CBBE 3BA and BHUNP/UNP genital/anal atlases are routed only to matching material geometry, separately from regular body maps
- Optional SOS Smurf Average, VectorPlexus Regular, and VectorPlexus Muscular textures match the actor's live addon, race, and elder variant
- Femaleold and race-specific face normals apply only when matching files exist; Astrid/Afflicted textures and BodySkin tint-mask DDS are excluded
- Ownership-aware cleanup does not delete another mod's texture keys
- All current body, hand, and foot targets are captured before the first live repaint, and transient detached texture sets are rejected instead of being traversed again during the same selection

### **Futanari Skin**

- The Futanari tab appears only when the selected actor currently has supported UBE SOS/TNG, CBBE 3BA TRX, or CBBE 3BA ERF genital geometry
- Only skin packs matching the actor's live body/addon combination are listed and applied; genital textures remain independent from the full BodySkin profile
- Default futanari skin removes only BCNG genital texture overrides and restores the installed addon's original material
- The selected profile remains saved if the genital addon is temporarily removed and is reapplied when the same supported type returns
- Missing channels are left unchanged, and TRX wet companions such as **wetschlong_110_s.dds** are preserved beside the selected cached skin

### **Player Tint**

- Install multiple tint packs and choose a pack from the Tint tab
- Automatically select a usable DDS for each layer and the player's current race
- Adjust color and opacity per layer immediately in game
- Restore the exact RaceMenu value captured before Body Change NG first changed that layer
- Reapply the confirmed tint selection after RaceMenu rebuilds the player

### **NPC Distribution**

- Rules are evaluated from top to bottom; the first matching rule owns Body and Skin
- Body and Skin can independently distribute selected entries, be excluded from distribution, or be left unchanged
- Targets include all NPCs, custom followers, elders, plugins, races, factions, keywords, classes, names, and exact NPC base FormIDs
- Faction, race, keyword, and class targets use plugin plus local FormID; unnamed forms remain selectable
- One selected preset or skin pack is fixed; multiple choices produce stable per-NPC random results
- Eight editable starter exclusions remain: custom followers and elders of both sexes exclude Body only; Argonians and Khajiit of both sexes exclude Skin only
- Edit every condition and pool in game, then distribute to loaded NPCs immediately or save the edits for the next launch
- Evaluated actor results are kept in the SKSE co-save to avoid redistributing unchanged NPCs

**Rules file**
`Data\SKSE\Plugins\BodyChangeNGdistribution.json`

The in-game editor writes this file, so manual JSON editing is not required. To preserve your rules when reinstalling the mod, Skyrim, or an MO2 profile, back up the file, copy it back to the same path, and press **Load saved values** in the NPC Distribution window.

### **Outfit Correction and Randomization**

- Optional CBBE 3BA breast correction while clothed, with a separate nipple-correction toggle
- Optional stable CBBE 3BA NPC nipple and genital slider randomization
- UBE uses a materially different slider system, so these anatomy options are not applied to UBE actors; selecting one shows an in-game warning and tooltips
- Global switches remain available in mixed UBE-player/CBBE-NPC installations and are enforced per actor

### **UI and Input**

- Korean, English, and Simplified Chinese UI
- Default F7 menu hotkey can be rebound in Mod Settings, including Ctrl, Shift, and Ctrl+Shift combinations
- Mouse, keyboard arrows/WASD, and gamepad D-pad navigation
- Gamepad confirm and cancel actions
- Native IME text input, Backspace, search fields, favorites, and favorites-only filtering

---

## **REQUIREMENTS**

- Skyrim SE 1.5.97 or a verified Skyrim AE 1.6.x runtime through 1.6.1179
- Matching SKSE64
- Address Library for SKSE Plugins
- RaceMenu with BodyMorph and NiOverride

---

## **INSTALLATION**

1. Install the main archive with MO2
2. Keep the included folder structure intact and enable the mod
3. Launch Skyrim through SKSE and press F7

---

## **ADDING BODY PRESETS, SKIN PACKS, FUTANARI SKINS, AND TINT PACKS**

All paths below are relative to an MO2 mod root. You may place these assets inside Body Change NG or in separate enabled MO2 mods that provide the same virtual paths.

### **Body Preset XML**
`CalienteTools\BodySlide\SliderPresets\*.xml`

Place standard BodySlide preset XML files in this folder.

### **Skin Packs**
**Conventional:** BodySkin\YourSkinPack\Textures\actors\character\...
**CBBE 3BA female genital/anal atlas:** femalebody_etc_v2_1.dds plus _msn, _sk, and _s in the conventional female directory. These files target the matching 3BA/3BBB vagina and anus geometries that share the atlas, never another body part.
**BHUNP/UNP female genital/anal atlas:** BakaUNP\VaginalAnalCanal2.dds plus _msn, _sk, and _s under the conventional female directory. These files target the matching vagina, anus, and canal geometries only.
**Argonian:** BodySkin\YourSkinPack\Textures\actors\character\argonianfemale\... and argonianmale\...
**Khajiit:** BodySkin\YourSkinPack\Textures\actors\character\khajiitfemale\... and khajiitmale\...
**Male:** BodySkin\YourSkinPack\Textures\actors\character\male\...
**SOS addons:** BodySkin\YourSkinPack\Textures\actors\character\SOS\... — preserve the original Smurf Average, VectorPlexus Regular, or VectorPlexus Muscular folder and DDS names; install the corresponding addon separately
**Elder/race variants:** preserve femaleold and humanoid race folders inside the same pack; missing variant files keep the actor's underlying texture
**UBE 2.0:** BodySkin\YourSkinPack\Textures\!UBE\Body\femalebody_1_[d/n/sk].dds
BodySkin\YourSkinPack\Textures\!UBE\Head\femalehead_[d/n/sk].dds

Create one folder per skin pack and preserve the skin mod's original Textures tree and DDS files. One pack may contain all four Argonian/Khajiit race-sex folders; each populated combination is detected separately. Do not move UBE atlases into the conventional female folder. Catalog rows are matched to the selected actor's race, sex, and detected body family.

### **Futanari Skin Packs**
**UBE with UBE SOS/TNG:** `Futanari\YourSkinPack\Textures\!UBE\Body\...`
**CBBE 3BA with TRX:** `Futanari\YourSkinPack\Textures\[TRX] Futa addon\Regular\Default\...`
**CBBE 3BA with ERF:** `Futanari\YourSkinPack\Textures\ERF_Futanari\FairSkinCBBE\...`

Create one folder per pack and preserve the original DDS names. The catalog appears only while the selected actor has supported genital geometry and shows only the matching type. Press **Refresh** on the Futanari tab after adding or replacing a pack while Skyrim is running.

### **Tint Packs**
`TintMask\YourTintPack\textures\actors\character\character assets\tintmasks\*.dds`

Create one folder per tint pack and preserve its RaceMenu tint-mask filenames and folder structure. Each folder directly under **TintMask** becomes one entry in the in-game catalog.

Only tint-mask-based tints are supported; overlay-based tints are not supported.
For a UBE-only tint-mask pack, include **UBE** in the top-level pack name. Packs marked **COtR** are treated as compatible with both UBE and conventional female heads.

**Adding files while Skyrim is running**

BodySlide preset XML files and BodySkin, Futanari, or TintMask pack folders may be added or replaced while the game is running. Open the corresponding tab and press **Refresh** to rescan the files and update the list without restarting Skyrim.

The archive includes a README in every user-asset folder and a valid schema-4 distribution JSON with eight editable starter exclusions. Existing schema-3 files remain readable and are upgraded when saved.

---

## **OPTIONAL OBODY NG JSON COMPATIBILITY**

**This is optional.** Body Change NG works without OBody NG or its JSON. Use this only if you want to reuse OBody NG-format distribution conditions, outfit-correction rules, or both.

**Optional OBody NG file**
`Data\SKSE\Plugins\OBody_presetDistributionConfig.json`

Place it beside `BodyChangeNGdistribution.json` under `Data\SKSE\Plugins`. Do not rename either file, merge the two JSON files, or replace Body Change NG's own JSON.

- **Distribution conditions** — press **Load saved values** in the NPC Distribution window to import supported OBody distribution rules when the file exists
- **Outfit-correction rules** — press **Register OBody NG outfit-correction rules** in the Outfit · randomization window
- **Independent choices** — import only distribution conditions, register only outfit-correction rules, or use both
- **Read only** — the OBody JSON is never read automatically at startup and is never modified by Body Change NG

The [OBody Next Generation ORefit JSON Master List](https://www.nexusmods.com/skyrimspecialedition/mods/105052) is a supported optional source.

---

## **COMPATIBILITY NOTES**

- Body Change NG does not edit NIFs, Skin Armor records, ArmorAddon records, or equipped slots
- Confirmed Body, Skin, and Tint selections are reapplied after RaceMenu closes
- After removing legacy BodyChange.esp, obsolete non-UBE RaceMenu face references can be repaired with an adjacent backup and available High Poly Head/vanilla fallback; UBE custom-head presets are preserved
- Skin support replaces matching texture channels; it does not create missing geometry or change its UV mapping
- **Racial Skin Variance (RSV)** — Body Preset and TintMask features are independent of RSV. When a BCNG BodySkin is selected for an RSV actor, BCNG targets that actor's live RSV Skin Armor and applies every available body, hands, feet, face, and conditional channel. RSV keeps ownership of its serialized FaceGen keys; BCNG paints its selected face on the live node and performs one coalesced reconciliation after RSV's deferred node update. Clearing the BCNG skin naturally reveals RSV again. Missing BCNG channels continue to use the RSV/base texture
- **Mu Dynamic NormalMap** — supported normal-detail, mask, and overlay companion files remain beside the selected cached normal map so the full material bundle updates together
- **OverlayFix** — actor-update and asynchronous-work boundaries were tightened to improve coexistence

---

## **CREDITS & LICENSE**

Body Change NG is licensed under [GNU GPLv3](https://www.gnu.org/licenses/gpl-3.0.html). The complete source code, build scripts, and matching version tags are available on [GitHub](https://github.com/compilecraftworks/Body-Change-NG). Nexus provides the MO2-ready Release ZIP only.

Credits to the authors of CommonLibSSE-NG, Dear ImGui, pugixml, nlohmann/json, SKSE64, Address Library for SKSE Plugins, and RaceMenu. Detailed third-party notices and license texts are included in the distribution ZIP. All respective rights belong to their original authors.
